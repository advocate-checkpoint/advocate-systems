extern crate rand;

use std::convert::TryInto;

use std::time::SystemTime;
use rand::Rng;
use bincode::{serialize};
use serde::{Serialize, Deserialize};
use ring::digest::{SHA256, digest};
use crate::crypto::hash::{H256, Hashable};
use crate::transaction::{Transaction};
use crate::crypto::merkle::{MerkleTree};

// TODO:
// Add latest checkpoint information
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Header {
    pub parent: H256,
    pub nonce: u32,
    pub difficulty: H256,
    pub timestamp: u128,
    pub merkle_root: [u8; 32],
}


#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Content {
    pub data: Vec<Transaction>,
}

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct Block {
    pub header: Header,
    pub content: Content,
}

impl Hashable for Header {
    fn hash(&self) -> H256 {
        digest(&SHA256, &serialize(&self).unwrap()).into()
    }
}

impl Hashable for Block {
    fn hash(&self) -> H256 {
        self.header.hash()
    }
}

impl Block {
    pub fn genesis() -> Self {
        let mut rng = rand::thread_rng();
        // ? about difficulty generation
        let mut difficulty: [u8; 32] = [255; 32];

        // difficulty with first 4 bit 0
        // difficulty[0] = 15;

        // difficulty with first 8 bit 0
        // difficulty[0] = 0;

        // diffculty with first 12 bit 0
        // difficulty[0] = 0;
        // difficulty[1] = 31;

        // diffculty with first 14 bit 0
        // difficulty[0] = 0;
        // difficulty[1] = 3;

        // difficulty with first 15 bit 0
        // difficulty[0] = 0;
        // difficulty[1] = 1;

        // // difficulty with first 16 bit 0
        // difficulty[0] = 0;
        // difficulty[1] = 0;
        
        // difficulty with first 32 bit 0
        // difficulty[4] = 128;

        Block {
            header: Header {
                parent: [0; 32].into(), // null parent
                nonce: 0,
                difficulty: difficulty.into(), 
                timestamp: 0, 
                merkle_root: MerkleTree::new::<Transaction>(&Vec::new()).root().into(),
            }, 
            content: Content {
                data: Vec::new(), // no transaction in genesis block 
            }
        }
    }

    pub fn genesis_with_difficulty(difficulty: H256) -> Self{
        Block {
            header: Header {
                parent: [0; 32].into(), // null parent
                nonce: 0,
                difficulty: difficulty, 
                timestamp: 0, 
                merkle_root: MerkleTree::new::<Transaction>(&Vec::new()).root().into(),
            }, 
            content: Content {
                data: Vec::new(), // no transaction in genesis block 
            }
        }
    }
    /// temporary new block generation because there is no transaction
    pub fn new(parent: &H256, nonce: u32, difficulty: &H256) -> Self {
        Block {
            header: Header {
                parent: *parent, 
                nonce: nonce,
                difficulty: *difficulty,
                timestamp: get_time(),
                merkle_root: MerkleTree::new::<Transaction>(&Vec::new()).root().into(),
            },
            content: Content {
                data: Vec::new(),
            }
        }
    }


    /* Getter */
    pub fn get_parent(&self) -> H256 {
        self.header.parent
    }

    pub fn get_difficulty(&self) -> H256 {
        self.header.difficulty
    }
    pub fn set_difficulty(&mut self, difficulty: H256){
        self.header.difficulty = difficulty;
    }
    pub fn get_timestamp(&self) -> u128 {
        self.header.timestamp
    }
}

#[cfg(any(test, test_utilities))]
pub mod test {
    use super::*;
    use crate::crypto::hash::H256;

    pub fn generate_random_block(parent: &H256) -> Block {
        let mut rng = rand::thread_rng();
        let random_bytes: Vec<u8> = (0..32).map(|_| rng.gen()).collect();
        let mut difficulty_bytes = [0; 32];
        difficulty_bytes.copy_from_slice(&random_bytes);
        Block {
            header: Header{
                parent: *parent,
                nonce: rng.gen::<u32>(),
                difficulty: difficulty_bytes.into(),
                timestamp: get_time(),
                merkle_root: MerkleTree::new::<Transaction>(&Vec::new()).root().into(),
            },
            content: Content {
                data: Vec::new(),
            }
        }
    }

    pub fn generate_random_valid_block(parent: &H256) -> Block {
        let mut rng = rand::thread_rng();
        let random_bytes: Vec<u8> = (0..32).map(|_| rng.gen()).collect();
        let mut difficulty_bytes = [0; 32];
        for i in 0..32{
            difficulty_bytes[i] = 255;
        }
        Block {
            header: Header{
                parent: *parent,
                nonce: rng.gen::<u32>(),
                difficulty: difficulty_bytes.into(),
                timestamp: get_time(),
                merkle_root: MerkleTree::new::<Transaction>(&Vec::new()).root().into(),
            },
            content: Content {
                data: Vec::new(),
            }
        }
    }

    pub fn generate_random_block_with_checkpoint(parent_hash:H256) -> Block{
        let mut rng = rand::thread_rng();
        let mut difficulty_bytes = [0; 32];
        for i in 0..32{
            difficulty_bytes[i] = 255;
        }
        Block {
            header: Header{
                parent: parent_hash,
                nonce: rng.gen::<u32>(),
                difficulty: difficulty_bytes.into(),
                timestamp: get_time(),
                merkle_root: MerkleTree::new::<Transaction>(&Vec::new()).root().into(),
            },
            content: Content {
                data: Vec::new(),
            }
        }
    }

    pub fn generate_random_invalid_block(parent: &H256) -> Block {
        let mut rng = rand::thread_rng();
        let mut difficulty_bytes = [0; 32];
        Block {
            header: Header{
                parent: *parent,
                nonce: rng.gen::<u32>(),
                difficulty: difficulty_bytes.into(),
                timestamp: get_time(),
                merkle_root: MerkleTree::new::<Transaction>(&Vec::new()).root().into(),
            },
            content: Content {
                data: Vec::new(),
            }
        }
    }

}

/// Get the current UNIX timestamp
fn get_time() -> u128 {
    let cur_time = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH);
    match cur_time {
        Ok(v) => {
            return v.as_millis();
        }
        Err(e) => println!("Error parsing time: {:?}", e),
    }
    // TODO: there should be a better way of handling this, or just unwrap and panic
    0
}