use super::message::Message;
use super::peer;
use crate::network::server::Handle as ServerHandle;
use crate::blockchain::{Blockchain, CheckpointResult, BlockResult};
use crate::checkpoint::Checkpoint;
use crate::crypto::hash::H256;
use crate::crypto::hash::Hashable;
use std::sync::{ Arc, Mutex };
use crossbeam::channel;
use log::{debug, warn, info};
use std::time;
use std::thread;

use hex;

#[derive(Clone)]
pub struct Context {
    msg_chan: channel::Receiver<(Vec<u8>, peer::Handle)>,
    num_worker: usize,
    server: ServerHandle,
    blockchain: Arc<Mutex<Blockchain>>,
}

pub fn new(
    num_worker: usize,
    msg_src: channel::Receiver<(Vec<u8>, peer::Handle)>,
    server: &ServerHandle,
    blockchain: &Arc<Mutex<Blockchain>>,
) -> Context {
    Context {
        msg_chan: msg_src,
        num_worker,
        server: server.clone(),
        blockchain: Arc::clone(blockchain),
    }
}

impl Context {
    pub fn start(self) {
        let num_worker = self.num_worker;
        for i in 0..num_worker {
            let cloned = self.clone();
            thread::spawn(move || {
                cloned.worker_loop();
                warn!("Worker thread {} exited", i);
            });
        }
    }

    fn worker_loop(&self) {
        loop {
            let msg = self.msg_chan.recv().unwrap();
            let (msg, peer) = msg;
            let msg: Message = bincode::deserialize(&msg).unwrap();
            match msg {
                Message::Ping(nonce) => {
                    debug!("Ping: {}", nonce);
                    peer.write(Message::Pong(nonce.to_string()));
                }
                Message::Pong(nonce) => {
                    debug!("Pong: {}", nonce);
                }
                Message::NewBlockHashes(hashes) => {
                    // let addr = peer.get_reply_addr();
                    // info!("Receives new blocks from {}", &addr);

                    let the_chain = self.blockchain.lock().unwrap();
                    let unknown_blocks = the_chain.check_blocks_existence(&hashes);
                    drop(the_chain);
                    // if the blocks are all in the chain then do nothing
                    // otherwise, send getBlock to the peer
                    if !unknown_blocks.is_empty() {
                        peer.write(Message::GetBlocks(unknown_blocks));
                    }
                }
                Message::GetBlocks(hashes) => {
                    // let addr = peer.get_reply_addr();
                    // info!("Receives blocks request from {}", addr);
                    
                    let the_chain = self.blockchain.lock().unwrap();
                    let founded_blocks = the_chain.select_blocks(&hashes);
                    drop(the_chain);
                    // if the blocks are all in the chain then do nothing
                    // otherwise, send Blocks to the peer
                    if !founded_blocks.is_empty() {
                        peer.write(Message::Blocks(founded_blocks));
                    } 
                }
                Message::Blocks(blocks) => {
                    // let addr = peer.get_reply_addr();
                    // info!("Receives blocks from {}", addr);
                    for block in blocks.iter() {
                        info!("Receives: {}", block.hash());
                    }
                    let mut the_chain = self.blockchain.lock().unwrap();
                    let mut received_blocks: Vec<H256> = Vec::new();
                    let mut received_checkpoints: Vec<H256> = Vec::new();
                    let mut missed_blocks: Vec<H256> = Vec::new();

                    for block in blocks.iter() {
                        let result = the_chain.receive_block(block);
                        match result.message_type {
                            BlockResult::DropBlock => {},
                            BlockResult::GetBlock => {
                                for missed_block in result.blockhashes.unwrap().iter() {
                                    missed_blocks.push(missed_block.clone());
                                }
                            },
                            BlockResult::ReceivedBlocks => {
                                for received_block in result.blockhashes.unwrap().iter() {
                                    received_blocks.push(received_block.clone());
                                }
                                if result.checkpoints.is_some() {
                                    for received_checkpoint in result.checkpoints.unwrap().iter() {
                                        received_checkpoints.push(received_checkpoint.clone());
                                    }
                                }
                            }
                        }
                    }
                    drop(the_chain);
                    if !received_blocks.is_empty() {
                        self.server.broadcast(Message::NewBlockHashes(received_blocks));
                    }

                    if !received_checkpoints.is_empty() {
                        for received_checkpoint in received_checkpoints.iter() {
                            info!("received new CP: {}", received_checkpoint.clone());
                        }
                        self.server.broadcast(Message::NewCheckpoints(received_checkpoints));
                    }
                    
                    if !missed_blocks.is_empty() {
                        peer.write(Message::GetBlocks(missed_blocks));
                    }

                    // let newly_inserted_blocks = the_chain.select_unfound_hashes(&blocks);

                    // // implemented as for timing purpose
                    // let newly_timestamp = the_chain.select_unfound_timestamp(&blocks);
                    // let now = time::SystemTime::now().duration_since(time::UNIX_EPOCH).unwrap().as_millis() as u64;
                    // the_chain.update_block_avg_relay(&newly_timestamp, now);

                    // for the_block in blocks.iter() {
                    //     the_chain.insert(&the_block);
                    // }
                    
                    // if newly_inserted_blocks.len() > 0 {
                    //     self.server.broadcast(Message::NewBlockHashes(newly_inserted_blocks));
                    // }
                    
                    // let unfound_hashes = the_chain.select_unfound_hashes(&blocks);
                    // if unfound_hashes.len() > 0 {
                    //     peer.write(Message::GetBlocks(unfound_hashes));
                    // }   
                }
                // Message::NewTransactionHashes(hashes) => {
                //     let addr = peer.get_reply_addr();
                //     info!("Receives new transactions from {}", &addr);
                // }
                Message::NewCheckpoints(checkpoint_hashes) => {
                    let the_chain = self.blockchain.lock().unwrap();
                    let mut missed_checkpoint_hashes: Vec<H256> = Vec::new();
                    for checkpoint_hash in checkpoint_hashes.iter() {
                        if !the_chain.check_checkpoint_existence(checkpoint_hash) {
                            missed_checkpoint_hashes.push(checkpoint_hash.clone());
                        }
                    }
                    drop(the_chain);
                    if !missed_checkpoint_hashes.is_empty() {
                        peer.write(Message::GetCheckpoints(missed_checkpoint_hashes));
                        // info!("New checkpoint may be available");
                    }
                }
                Message::GetCheckpoints(checkpoint_hashes) => {
                    let the_chain = self.blockchain.lock().unwrap();
                    let requested_chain = the_chain.get_messager_checkpoints(&checkpoint_hashes);
                    drop(the_chain);
                    if !requested_chain.is_empty() {
                        peer.write(Message::Checkpoints(requested_chain));
                        // info!("Requested new checkpoint sent");
                    }
                }
                Message::Checkpoints(checkpoints) =>{
                    let mut the_chain = self.blockchain.lock().unwrap();
                    let mut missed_blocks: Vec<H256> = Vec::new();
                    let mut received_checkpoints: Vec<H256> = Vec::new();
                    for checkpoint in checkpoints.iter() {
                        let ret = the_chain.receive_checkpoint(checkpoint);
                        match ret.message_type {
                            CheckpointResult::DropCheckpoint => {},
                            CheckpointResult::GetBlock => {
                                missed_blocks.push(ret.blockhash.unwrap());
                            },
                            CheckpointResult::ReceivedCheckpoint => {
                                info!("received new CP: {}", checkpoint.hash());
                                received_checkpoints.push(ret.checkpoint.unwrap());
                            }
                        }
                    }
                    drop(the_chain);
                    if !missed_blocks.is_empty() {
                        peer.write(Message::GetBlocks(missed_blocks));
                    }

                    if !received_checkpoints.is_empty() {
                        self.server.broadcast(Message::NewCheckpoints(received_checkpoints));
                    }
                }
                Message::Bootstrap(chain_id) => {
                    let requested_chain_id = chain_id;
                    //TODO: Ask for the chain (will happen naturally with GetBlocks) and latest checkpoint
                }
            }
        }
    }
}
