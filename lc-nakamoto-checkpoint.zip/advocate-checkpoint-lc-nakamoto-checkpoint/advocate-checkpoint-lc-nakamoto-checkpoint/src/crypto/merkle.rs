use ring::digest::{digest, Context, SHA256, Digest};
use super::hash::{Hashable, H256};

/// A Merkle tree.
#[derive(Debug, Default)]
pub struct MerkleTree {
    nodes: Vec<Vec<[u8; 32]>>,
}

impl MerkleTree {
    pub fn new<T>(data: &[T]) -> Self where T: Hashable, {
        
        let mut nodes: Vec<Vec<[u8; 32]>> = Vec::new();
        let mut level1: Vec<[u8; 32]> = Vec::new();
        
        // no data, return empty merkle tree
        if data.len() == 0 {
            nodes.push(level1);
            return MerkleTree{ nodes: nodes};
        }

        for item in data {
            level1.push(item.hash().into());
        }

        // if data has only 1, extends to 2.
        // otherwise, return closest 2-exponential value
        let mut count = level1.len() as f64;
        if count == 1.0 {
            count = 2.0;
        } else {
            count = count.log2();
            if count.fract() != 0.0 {
                count = count.floor() + 1.0;
            }
        }

        let last_item = *level1.last_mut().unwrap();
        for _ in 0..(count.exp2() - level1.len() as f64) as i32 {
            level1.push(last_item);
        }
        nodes.push(level1);

        let mut counter = nodes[0].len()/2;
        let mut curr_level = 0;
        while nodes.last().unwrap().len() != 1 {
            let mut level: Vec<[u8; 32]> = Vec::new();
            for i in 0..counter {
                let mut ctx = Context::new(&SHA256);
                ctx.update(&nodes[curr_level][i*2]);
                ctx.update(&nodes[curr_level][i*2+1]);
                level.push(H256::from(ctx.finish()).into());
            }
            nodes.push(level);
            curr_level = curr_level + 1;
            counter = nodes[curr_level].len()/2;
        }
        MerkleTree{ nodes: nodes }
    }

    pub fn root(&self) -> H256 {
        if self.nodes[0].len() == 0 {
            return [0; 32].into();
        } 
        H256::from(self.nodes.last().unwrap()[0])
    }

    /// Returns the Merkle Proof of data at index i
    pub fn proof(&self, index: usize) -> Vec<H256> {
        let mut level = index as f64;
        let mut result: Vec<H256> = Vec::new();

        for i in 0..self.nodes.len()-1 {
            level = level / 2.0;
            if level.fract() != 0.0 {
                result.push(H256::from(self.nodes[i][(level * 2.0 - 1.0) as usize]));
            } else {
                result.push(H256::from(self.nodes[i][(level * 2.0 + 1.0) as usize]));
            }
            level = level.floor();
        }
        result
    }
}

/// Verify that the datum hash with a vector of proofs will produce the Merkle root. Also need the
/// index of datum and `leaf_size`, the total number of leaves.
pub fn verify(root: &H256, datum: &H256, proof: &[H256], index: usize, leaf_size: usize) -> bool {
    let mut test = *datum;
    let mut idx = index as f64;
    for item in proof {
        idx = idx / 2.0;
        let mut ctx = Context::new(&SHA256);
        if idx.fract() != 0.0 {
            ctx.update(item.as_ref());
            ctx.update(test.as_ref());
        } else {
            ctx.update(test.as_ref());
            ctx.update(item.as_ref());
        }
        test = H256::from(ctx.finish());
        idx = idx.floor();
    }

    *root == test
}

#[cfg(test)]
mod tests {
    use crate::crypto::hash::H256;
    use super::*;

    macro_rules! gen_merkle_tree_data {
        () => {{
            vec![
                (hex!("0a0b0c0d0e0f0e0d0a0b0c0d0e0f0e0d0a0b0c0d0e0f0e0d0a0b0c0d0e0f0e0d")).into(),
                (hex!("0101010101010101010101010101010101010101010101010101010101010202")).into(),
            ]
        }};
    }

    #[test]
    fn root() {
        let input_data: Vec<H256> = gen_merkle_tree_data!();
        let merkle_tree = MerkleTree::new(&input_data);
        let root = merkle_tree.root();
        assert_eq!(
            root,
            (hex!("6b787718210e0b3b608814e04e61fde06d0df794319a12162f287412df3ec920")).into()
        );
        // "b69566be6e1720872f73651d1851a0eae0060a132cf0f64a0ffaea248de6cba0" is the hash of
        // "0a0b0c0d0e0f0e0d0a0b0c0d0e0f0e0d0a0b0c0d0e0f0e0d0a0b0c0d0e0f0e0d"
        // "965b093a75a75895a351786dd7a188515173f6928a8af8c9baa4dcff268a4f0f" is the hash of
        // "0101010101010101010101010101010101010101010101010101010101010202"
        // "6b787718210e0b3b608814e04e61fde06d0df794319a12162f287412df3ec920" is the hash of
        // the concatenation of these two hashes "b69..." and "965..."
        // notice that the order of these two matters
    }

    #[test]
    fn proof() {
        let input_data: Vec<H256> = gen_merkle_tree_data!();
        let merkle_tree = MerkleTree::new(&input_data);
        let proof = merkle_tree.proof(1);
        assert_eq!(proof,
                   vec![hex!("b69566be6e1720872f73651d1851a0eae0060a132cf0f64a0ffaea248de6cba0").into()]
        );
        // "965b093a75a75895a351786dd7a188515173f6928a8af8c9baa4dcff268a4f0f" is the hash of
        // "0101010101010101010101010101010101010101010101010101010101010202"
    }

    #[test]
    fn verifying() {
        let input_data: Vec<H256> = gen_merkle_tree_data!();
        let merkle_tree = MerkleTree::new(&input_data);
        let proof = merkle_tree.proof(1);
        assert!(verify(&merkle_tree.root(), &input_data[1].hash(), &proof, 1, input_data.len()));
    }

    macro_rules! gen_merkle_tree_assignment2 {
        () => {{
            vec![
                (hex!("0000000000000000000000000000000000000000000000000000000000000011")).into(),
                (hex!("0000000000000000000000000000000000000000000000000000000000000022")).into(),
                (hex!("0000000000000000000000000000000000000000000000000000000000000033")).into(),
                (hex!("0000000000000000000000000000000000000000000000000000000000000044")).into(),
                (hex!("0000000000000000000000000000000000000000000000000000000000000055")).into(),
                (hex!("0000000000000000000000000000000000000000000000000000000000000066")).into(),
                (hex!("0000000000000000000000000000000000000000000000000000000000000077")).into(),
                (hex!("0000000000000000000000000000000000000000000000000000000000000088")).into(),
            ]
        }};
    }

    macro_rules! gen_merkle_tree_assignment2_another {
        () => {{
            vec![
                (hex!("1000000000000000000000000000000000000000000000000000000000000088")).into(),
                (hex!("2000000000000000000000000000000000000000000000000000000000000077")).into(),
                (hex!("3000000000000000000000000000000000000000000000000000000000000066")).into(),
                (hex!("4000000000000000000000000000000000000000000000000000000000000055")).into(),
                (hex!("5000000000000000000000000000000000000000000000000000000000000044")).into(),
                (hex!("6000000000000000000000000000000000000000000000000000000000000033")).into(),
                (hex!("7000000000000000000000000000000000000000000000000000000000000022")).into(),
                (hex!("8000000000000000000000000000000000000000000000000000000000000011")).into(),
            ]
        }};
    }

    #[test]
    fn assignment2_merkle_root() {
        let input_data: Vec<H256> = gen_merkle_tree_assignment2!();
        let merkle_tree = MerkleTree::new(&input_data);
        print!("Size: {}", merkle_tree.nodes.len());
        let root = merkle_tree.root();
        assert_eq!(
            root,
            (hex!("6e18c8441bc8b0d1f0d4dc442c0d82ff2b4f38e2d7ca487c92e6db435d820a10")).into()
        );
    }

    #[test]
    fn assignment2_merkle_verify() {
        let input_data: Vec<H256> = gen_merkle_tree_assignment2!();
        let merkle_tree = MerkleTree::new(&input_data);
        for i in 0.. input_data.len() {
            let proof = merkle_tree.proof(i);
            print!("{}", i);
            assert!(verify(&merkle_tree.root(), &input_data[i].hash(), &proof, i, input_data.len()));
        }
        let input_data_2: Vec<H256> = gen_merkle_tree_assignment2_another!();
        let merkle_tree_2 = MerkleTree::new(&input_data_2);
        assert!(!verify(&merkle_tree.root(), &input_data[0].hash(), &merkle_tree_2.proof(0), 0, input_data.len()));
    }

    #[test]
    fn assignment2_merkle_proof() {
        use std::collections::HashSet;
        let input_data: Vec<H256> = gen_merkle_tree_assignment2!();
        let merkle_tree = MerkleTree::new(&input_data);
        let proof = merkle_tree.proof(5);
        let proof: HashSet<H256> = proof.into_iter().collect();
        let p: H256 = (hex!("c8c37c89fcc6ee7f5e8237d2b7ed8c17640c154f8d7751c774719b2b82040c76")).into();
        assert!(proof.contains(&p));
        let p: H256 = (hex!("bada70a695501195fb5ad950a5a41c02c0f9c449a918937267710a0425151b77")).into();
        assert!(proof.contains(&p));
        let p: H256 = (hex!("1e28fb71415f259bd4b0b3b98d67a1240b4f3bed5923aa222c5fdbd97c8fb002")).into();
        assert!(proof.contains(&p));
    }
}
