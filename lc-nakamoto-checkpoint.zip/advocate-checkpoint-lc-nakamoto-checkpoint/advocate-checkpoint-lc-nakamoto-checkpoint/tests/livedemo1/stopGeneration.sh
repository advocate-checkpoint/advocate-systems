#!/usr/bin/env bash

curl http://127.0.0.1:7000/miner/pausecpgeneration
