#!/usr/bin/env bash

curl http://127.0.0.1:7000/miner/pausetransmission?lambda=4000
curl http://127.0.0.1:7001/miner/pausetransmission?lambda=6000
curl http://127.0.0.1:7002/miner/pausetransmission?lambda=6000
