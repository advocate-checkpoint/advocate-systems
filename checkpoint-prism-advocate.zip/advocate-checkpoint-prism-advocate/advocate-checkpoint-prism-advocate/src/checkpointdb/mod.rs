use crate::checkpoint::Checkpoint;
use crate::crypto::hash::{Hashable, H256};
use crate::config::*;

use bincode::{deserialize, serialize};
use rocksdb::{self, ColumnFamilyDescriptor, Options, SliceTransform, DB};
use std::sync::atomic::{AtomicU64, Ordering};

const CHECKPOINT_CF: &str = "CHECKPOINT";

/// Database that stores blocks.
pub struct CheckpointDatabase {
    /// The underlying RocksDB handle.
    db: rocksdb::DB,
    /// The number of blocks in this database.
    count: AtomicU64,
}

impl CheckpointDatabase {
    /// Open the database at the given path, and create a new one if missing.
    fn open<P: AsRef<std::path::Path>>(
        path: P,
        _config: BlockchainConfig, 
    ) -> Result<Self, rocksdb::Error> {
        let mut opts = Options::default();
        opts.set_prefix_extractor(SliceTransform::create_fixed_prefix(32));
        opts.optimize_for_point_lookup(512);
        let checkpoint_cf = ColumnFamilyDescriptor::new(CHECKPOINT_CF, opts);
        let cfs = vec![checkpoint_cf];
        let mut opts = Options::default();
        opts.create_if_missing(true);
        opts.create_missing_column_families(true);
        let db = DB::open_cf_descriptors(&opts, path, cfs)?;
        Ok(CheckpointDatabase {
            db,
            count: AtomicU64::new(0),
        })
    }

    /// Create a new database at the given path, and initialize the content.
    pub fn new<P: AsRef<std::path::Path>> (
        path: P, 
        config: BlockchainConfig,
    ) -> Result<Self, rocksdb::Error> {
        DB::destroy(&Options::default(), &path)?;
        let db = Self::open(&path, config.clone())?;
        let checkpoint_cf = db.db.cf_handle(CHECKPOINT_CF).unwrap();
        let mut counter: u64 = 0;
        db.db.put_cf(
            checkpoint_cf,
            &config.checkpoint_genesis.hash(),
            &serialize(&config.checkpoint_genesis).unwrap(),
        )?;
        counter += 1;
        db.count.store(counter, Ordering::Relaxed);
        Ok(db)
    }

    /// Load database from a given path
    pub fn load<P: AsRef<std::path::Path>>(
        path: P,
        config: BlockchainConfig,
    ) -> Result<Self, rocksdb::Error> {
        let db = Self::open(&path, config)?;
        Ok(db)
    }

    /// Insert a new certificate to the database and return the sequence number of the ceritificate
    pub fn insert(&self, checkpoint: &Checkpoint) -> Result<u64, rocksdb::Error> {
        let checkpoint_cf = self.db.cf_handle(CHECKPOINT_CF).unwrap();
        let hash: H256 = checkpoint.hash();
        let serialized = serialize(checkpoint).unwrap();
        let counter = self.count.fetch_add(1, Ordering::Relaxed);
        self.db.put_cf(checkpoint_cf, &hash, &serialized)?;
        Ok(counter)
    }

    pub fn insert_encoded(&self, hash: &H256, raw_checkpoint: &[u8]) -> Result<u64, rocksdb::Error> {
        let checkpoint_cf = self.db.cf_handle(CHECKPOINT_CF).unwrap();
        let counter = self.count.fetch_add(1, Ordering::Relaxed);
        self.db.put_cf(checkpoint_cf, hash, raw_checkpoint)?;
        Ok(counter)
    }

    /// Get a certificate from the database.
    pub fn get(&self, hash: &H256) -> Result<Option<Checkpoint>, rocksdb::Error> {
        let checkpoint_cf = self.db.cf_handle(CHECKPOINT_CF).unwrap();
        let serialized = self.db.get_pinned_cf(checkpoint_cf, hash)?;
        match serialized {
            None => Ok(None),
            Some(s) => Ok(Some(deserialize(&s).unwrap())),
        }
    }

    pub fn get_encoded(
        &self,
        hash: &H256,
    ) -> Result<Option<rocksdb::DBPinnableSlice>, rocksdb::Error> {
        let checkpoint_cf = self.db.cf_handle(CHECKPOINT_CF).unwrap();
        let serialized = self.db.get_pinned_cf(checkpoint_cf, hash)?;
        Ok(serialized)
    }
    
    pub fn contains(&self, hash: &H256) -> Result<bool, rocksdb::Error> {
        let checkpoint_cf = self.db.cf_handle(CHECKPOINT_CF).unwrap();
        let serialized = self.db.get_pinned_cf(checkpoint_cf, hash)?;
        match serialized {
            None => Ok(false),
            Some(_) => Ok(true),
        }
    }

    /// Get the number of blocks in the database.
    pub fn num_certificates(&self) -> u64 {
        self.count.load(Ordering::Relaxed)
    }
}
