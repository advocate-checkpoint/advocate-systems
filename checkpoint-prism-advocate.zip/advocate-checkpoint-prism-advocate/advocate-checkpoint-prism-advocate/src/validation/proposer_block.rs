use super::{check_proposer_block_exists, check_transaction_block_exists, check_voter_block_exists};
use crate::block::proposer::Content;
use crate::blockchain::BlockChain;
use crate::blockdb::BlockDatabase;
use crate::crypto::hash::H256;

pub fn get_missing_references(
    content: &Content,
    blockchain: &BlockChain,
    _blockdb: &BlockDatabase,
) -> Vec<H256> {
    let mut missing_blocks: Vec<H256> = vec![];

    // check whether the tx block referred are present
    for tx_block_hash in content.transaction_refs.iter() {
        let tx_block = check_transaction_block_exists(*tx_block_hash, blockchain);
        if !tx_block {
            missing_blocks.push(*tx_block_hash);
        }
    }

    // check whether the proposer blocks referred are present
    for prop_block_hash in content.proposer_refs.iter() {
        let prop_block = check_proposer_block_exists(*prop_block_hash, blockchain);
        if !prop_block {
            missing_blocks.push(*prop_block_hash);
        }
    }

    // check whether the checkpoint certificate block is present
    match &content.checkpoint {
        Some(cp) => {

            for proposer_block in cp.proposer_con.iter() {
                if !check_proposer_block_exists(*proposer_block, blockchain) {
                    missing_blocks.push(*proposer_block);
                }
            }

            for proposer_vec in cp.proposer_ref.iter() {
                for proposer_block in proposer_vec.iter() {
                    if !check_proposer_block_exists(*proposer_block, blockchain) {
                        missing_blocks.push(*proposer_block);
                    }
                }
            }
            for voter_block in cp.voter_chain.iter() {
                if !check_voter_block_exists(*voter_block, blockchain) {
                    missing_blocks.push(*voter_block);
                }
            }
        }, 
        None => {},
    }
    missing_blocks
}

pub fn check_ref_proposer_level(parent: &H256, content: &Content, blockchain: &BlockChain) -> bool {
    let parent_level = blockchain.proposer_level(parent).unwrap();
    for prop_block_hash in content.proposer_refs.iter() {
        let l = blockchain.proposer_level(prop_block_hash).unwrap();
        if l > parent_level {
            return false;
        }
    }
    true
}
