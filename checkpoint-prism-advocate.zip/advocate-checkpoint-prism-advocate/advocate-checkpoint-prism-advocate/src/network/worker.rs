use super::buffer::BlockBuffer;
use super::message::Message;
use super::peer;
use crate::block::{Block, Content};
use crate::blockchain::BlockChain;
use crate::blockdb::BlockDatabase;
use crate::checkpointdb::CheckpointDatabase;
use crate::config::*;
use crate::crypto::hash::{Hashable, H256};
use crate::experiment::performance_counter::PERFORMANCE_COUNTER;
use crate::handler::new_transaction;
use crate::handler::new_validated_block;
use crate::miner::memory_pool::MemoryPool;
use crate::miner::ContextUpdateSignal;
use crate::network::server::Handle as ServerHandle;
use crate::utxodb::UtxoDatabase;
use crate::validation::{self, BlockResult};
use crate::wallet::Wallet;
use crate::checkpoint::Checkpoint;
use crossbeam::channel;
use log::{debug, warn};
use std::collections::HashSet;

use std::sync::{Arc, Mutex};
use std::thread;

#[derive(Clone)]
pub struct Context {
    msg_chan: piper::Receiver<(Vec<u8>, peer::Handle)>,
    num_worker: usize,
    chain: Arc<BlockChain>,
    checkpointdb: Arc<CheckpointDatabase>,
    blockdb: Arc<BlockDatabase>,
    utxodb: Arc<UtxoDatabase>,
    wallet: Arc<Wallet>,
    mempool: Arc<Mutex<MemoryPool>>,
    context_update_chan: channel::Sender<ContextUpdateSignal>,
    server: ServerHandle,
    buffer: Arc<Mutex<BlockBuffer>>,
    recent_blocks: Arc<Mutex<HashSet<H256>>>, // blocks that we have received but not yet inserted
    requested_blocks: Arc<Mutex<HashSet<H256>>>, // blocks that we have requested but not yet received
    recent_checkpoints: Arc<Mutex<HashSet<H256>>>, // checkpoints that we have received but not yet inserted
    requested_checkpoints: Arc<Mutex<HashSet<H256>>>, // checkpoints that we have requested but not yet received
    config: BlockchainConfig,
}

pub fn new(
    num_worker: usize,
    msg_src: piper::Receiver<(Vec<u8>, peer::Handle)>,
    blockchain: &Arc<BlockChain>,
    blockdb: &Arc<BlockDatabase>,
    checkpointdb: &Arc<CheckpointDatabase>,
    utxodb: &Arc<UtxoDatabase>,
    wallet: &Arc<Wallet>,
    mempool: &Arc<Mutex<MemoryPool>>,
    ctx_update_sink: channel::Sender<ContextUpdateSignal>,
    server: &ServerHandle,
    config: BlockchainConfig,
) -> Context {
    Context {
        msg_chan: msg_src,
        num_worker,
        chain: Arc::clone(blockchain),
        checkpointdb: Arc::clone(checkpointdb),
        blockdb: Arc::clone(blockdb),
        utxodb: Arc::clone(utxodb),
        wallet: Arc::clone(wallet),
        mempool: Arc::clone(mempool),
        context_update_chan: ctx_update_sink,
        server: server.clone(),
        buffer: Arc::new(Mutex::new(BlockBuffer::new())),
        recent_blocks: Arc::new(Mutex::new(HashSet::new())),
        requested_blocks: Arc::new(Mutex::new(HashSet::new())),
        recent_checkpoints: Arc::new(Mutex::new(HashSet::new())),
        requested_checkpoints: Arc::new(Mutex::new(HashSet::new())),
        config,
    }
}

impl Context {
    pub fn start(self) {
        let num_worker = self.num_worker;
        for i in 0..num_worker {
            let cloned = self.clone();
            thread::spawn(move || {
                cloned.worker_loop();
                warn!("Worker thread {} exited", i);
            });
        }
    }

    fn worker_loop(&self) {
        loop {
            let msg = futures::executor::block_on(self.msg_chan.recv()).unwrap();
            PERFORMANCE_COUNTER.record_process_message();
            let (msg, mut peer) = msg;
            let msg: Message = bincode::deserialize(&msg).unwrap();
            match msg {
                Message::Ping(nonce) => {
                    debug!("Ping: {}", nonce);
                    peer.write(Message::Pong(nonce.to_string()));
                }
                Message::Pong(nonce) => {
                    debug!("Pong: {}", nonce);
                }
                Message::NewTransactionHashes(hashes) => {
                    debug!("Got {} new transaction hashes", hashes.len());
                    let mut hashes_to_request = vec![];
                    for hash in hashes {
                        if !self.mempool.lock().unwrap().contains(&hash) {
                            hashes_to_request.push(hash);
                        }
                    }
                    if !hashes_to_request.is_empty() {
                        peer.write(Message::GetTransactions(hashes_to_request));
                    }
                }
                Message::GetTransactions(hashes) => {
                    debug!("Asked for {} transactions", hashes.len());
                    let mut transactions = vec![];
                    for hash in hashes {
                        match self.mempool.lock().unwrap().get(&hash) {
                            None => {}
                            Some(entry) => {
                                transactions.push(entry.transaction.clone());
                            }
                        }
                    }
                    peer.write(Message::Transactions(transactions));
                }
                Message::Transactions(transactions) => {
                    debug!("Got {} transactions", transactions.len());
                    for transaction in transactions {
                        new_transaction(transaction, &self.mempool, &self.server);
                    }
                }
                Message::NewBlockHashes(hashes) => {
                    debug!("Got {} new block hashes", hashes.len());
                    let mut hashes_to_request = vec![];
                    for hash in hashes {
                        let in_blockdb = self.blockdb.contains(&hash).unwrap();
                        let requested_blocks = self.requested_blocks.lock().unwrap();
                        let requested = requested_blocks.contains(&hash);
                        drop(requested_blocks);
                        if !(in_blockdb || requested) {
                            hashes_to_request.push(hash);
                        }
                    }
                    let mut requested_blocks = self.requested_blocks.lock().unwrap();
                    for hash in &hashes_to_request {
                        requested_blocks.insert(*hash);
                    }
                    drop(requested_blocks);
                    if !hashes_to_request.is_empty() {
                        peer.write(Message::GetBlocks(hashes_to_request));
                    }
                }
                Message::GetBlocks(hashes) => {
                    debug!("Asked for {} blocks", hashes.len());
                    let mut blocks = vec![];
                    for hash in hashes {
                        match self.blockdb.get_encoded(&hash).unwrap() {
                            None => {}
                            Some(encoded_block) => {
                                blocks.push(encoded_block.to_vec());
                            }
                        }
                    }
                    peer.write(Message::Blocks(blocks));
                }
                Message::Blocks(encoded_blocks) => {
                    debug!("Got {} blocks", encoded_blocks.len());

                    // Optimization needed to reject invalid proposer and voter blocks. 
                    // So far the implementation will be just to ignore invalid proposer and corresponding
                    // voter blocks will recorded in blockdb but its information will stay in cache. 

                    // decode the blocks
                    let mut blocks: Vec<Block> = vec![];
                    let mut hashes: Vec<H256> = vec![];
                    for encoded_block in &encoded_blocks {
                        let block: Block = bincode::deserialize(&encoded_block).unwrap();
                        let hash = block.hash();

                        // now that the block that we request has arrived, remove it from the set
                        // of requested blocks. removing it at this stage causes a race condition,
                        // where the block could have been removed from requested_blocks but not
                        // yet inserted into the database. but this does not cause correctness
                        // problem and hardly incurs a performance issue (I hope)
                        let mut requested_blocks = self.requested_blocks.lock().unwrap();
                        requested_blocks.remove(&hash);
                        drop(requested_blocks);

                        // check POW here. If POW does not pass, discard the block at this
                        // stage
                        let pow_check = validation::check_pow_sortition_id(&block, &self.config);
                        match pow_check {
                            BlockResult::Pass => {}
                            _ => continue,
                        }

                        // check checkpoint certificate validity for the proposer block. 
                        let checkpoint_check = validation::check_block_checkpoint_validity(&block, &self.config);
                        match checkpoint_check {
                            BlockResult::Pass => {}
                            _ => continue,
                        }

                        // check whether the block is being processed. note that here we use lock
                        // to make sure that the hash either in recent_blocks, or blockdb, so we
                        // don't have a single duplicate
                        let mut recent_blocks = self.recent_blocks.lock().unwrap();
                        if recent_blocks.contains(&hash) {
                            drop(recent_blocks);
                            continue;
                        }
                        // register this block as being processed
                        recent_blocks.insert(hash);
                        drop(recent_blocks);

                        // TODO: consider the ordering here. I'd expect a lot of duplicate blocks
                        // to proceed to this step, which means a lot of useless database lookups
                        // and lock/unlocks
                        // detect duplicates
                        if self.blockdb.contains(&hash).unwrap() {
                            let mut recent_blocks = self.recent_blocks.lock().unwrap();
                            recent_blocks.remove(&hash);
                            drop(recent_blocks);
                            continue;
                        }

                        // store the block into database
                        self.blockdb.insert_encoded(&hash, &encoded_block).unwrap();

                        // now that this block is store, remove the reference
                        let mut recent_blocks = self.recent_blocks.lock().unwrap();
                        recent_blocks.remove(&hash);
                        drop(recent_blocks);

                        blocks.push(block);
                        hashes.push(hash);
                    }

                    for block in &blocks {
                        PERFORMANCE_COUNTER.record_receive_block(&block);
                    }

                    // tell peers about the new blocks
                    // TODO: we will do this only in a reasonable network topology
                    if hashes.is_empty() {
                        continue; // end processing this message
                    }
                    self.server
                        .broadcast(Message::NewBlockHashes(hashes.clone()));

                    // process each block
                    let mut to_process: Vec<Block> = blocks;
                    let mut to_request: Vec<H256> = vec![];
                    // broadcast checkpoint only if the process receives one
                    let mut to_broadcast: Vec<H256> = vec![];
                    let mut context_update_sig = vec![];
                    while let Some(block) = to_process.pop() {
                        // check data availability
                        // make sure checking data availability and buffering are one atomic
                        // operation. see the comments in buffer.rs

                        let mut buffer = self.buffer.lock().unwrap();
                        let data_availability =
                            validation::check_data_availability(&block, &self.chain, &self.blockdb);
                        match data_availability {
                            BlockResult::Pass => drop(buffer),
                            BlockResult::MissingReferences(r) => {
                                debug!(
                                    "Missing {} referred blocks for block {:.8}",
                                    r.len(),
                                    block.hash()
                                );
                                for block in r.iter() {
                                    debug!(
                                        "Missing block: {:.8}", block
                                    );
                                }
                                buffer.insert(block, &r);
                                to_request.extend_from_slice(&r);
                                drop(buffer);
                                continue;
                            }
                            _ => unreachable!(),
                        }

                        // check checkpoint certificate appearance rule for the proposer block
                        let checkpoint_appearance_check = 
                            validation::check_checkpoint_appearance(&block, &self.config, &self.chain);
                        match checkpoint_appearance_check {
                            BlockResult::Pass => {},
                            _ => {
                                warn!(
                                    "Ignoring invalid block {:.8}: {}",
                                    block.hash(),
                                    checkpoint_appearance_check,
                                );
                                continue;
                            }
                        }

                        // check sortition proof and content semantics
                        let sortition_proof =
                            validation::check_sortition_proof(&block, &self.config);
                        match sortition_proof {
                            BlockResult::Pass => {}
                            _ => {
                                warn!(
                                    "Ignoring invalid block {:.8}: {}",
                                    block.hash(),
                                    sortition_proof
                                );
                                continue;
                            }
                        }
                        let content_semantic =
                            validation::check_content_semantic(&block, &self.chain, &self.blockdb);
                        match content_semantic {
                            BlockResult::Pass => {}
                            _ => {
                                warn!(
                                    "Ignoring invalid block {:.8}: {}",
                                    block.hash(),
                                    content_semantic
                                );
                                continue;
                            }
                        }

                        match &block.content {
                            Content::Proposer(c) => {
                                if c.checkpoint.is_some() {
                                    let checkpoint: &Checkpoint = c.checkpoint.as_ref().unwrap();
                                    let hash = checkpoint.hash();
                                    if !self.checkpointdb.contains(&hash).unwrap() {
                                        self.checkpointdb.insert(checkpoint).unwrap();
                                        self.chain.insert_checkpoint(checkpoint).unwrap();
                                        to_broadcast.push(hash);
                                    }
                                }
                            }
                            _ => {}
                        }
                        debug!("Processing block {:.8}", block.hash());
                        new_validated_block(
                            &block,
                            &self.mempool,
                            &self.blockdb,
                            &self.chain,
                            &self.server,
                        );
                        context_update_sig.push(match &block.content {
                            Content::Proposer(_) => ContextUpdateSignal::NewProposerBlock,
                            Content::Voter(c) => ContextUpdateSignal::NewVoterBlock(c.chain_number),
                            Content::Transaction(_) => ContextUpdateSignal::NewTransactionBlock,
                        });
                        let mut buffer = self.buffer.lock().unwrap();
                        let mut resolved_by_current = buffer.satisfy(block.hash());
                        let resolved_checkpoint_by_current = match &block.content {
                            Content::Proposer(_) => {
                                buffer.satisfy_checkpoint(block.hash())
                            }, 
                            _ => None,
                        };
                        drop(buffer);
                        if !resolved_by_current.is_empty() {
                            debug!(
                                "Resolved dependency for {} buffered blocks",
                                resolved_by_current.len()
                            );
                        }
                        for b in resolved_by_current.drain(..) {
                            to_process.push(b);
                        }

                        if resolved_checkpoint_by_current.is_some() {
                            let checkpoint = resolved_checkpoint_by_current.unwrap();
                            let hash = checkpoint.hash();
                            self.checkpointdb.insert(&checkpoint).unwrap();
                            self.chain.insert_checkpoint(&checkpoint).unwrap();
                            to_broadcast.push(hash);
                        }
                    }
                    // tell the miner to update the context
                    for sig in context_update_sig {
                        self.context_update_chan.send(sig).unwrap();
                    }

                    if !to_broadcast.is_empty() {
                        self.server.broadcast(
                            Message::NewCheckpoints(to_broadcast)
                        );
                    }
                    if !to_request.is_empty() {
                        to_request.sort();
                        to_request.dedup();
                        peer.write(Message::GetBlocks(to_request));
                    }
                }
                Message::NewCheckpoints(checkpoints) => {
                    debug!("Got {} new checkpoints", checkpoints.len());
                    let mut checkpoints_to_request = vec![];
                    for checkpoint in checkpoints {
                        let in_blockdb = self.checkpointdb.contains(&checkpoint).unwrap();
                        let requested_checkpoints = self.requested_checkpoints.lock().unwrap();
                        let requested = requested_checkpoints.contains(&checkpoint);
                        drop(requested_checkpoints);
                        if !(in_blockdb || requested) {
                            checkpoints_to_request.push(checkpoint);
                        }
                    }
                    let mut requested_checkpoints = self.requested_checkpoints.lock().unwrap();
                    for hash in &checkpoints_to_request {
                        requested_checkpoints.insert(*hash);
                    }
                    drop(requested_checkpoints);
                    if !checkpoints_to_request.is_empty() {
                        peer.write(Message::GetCheckpoints(checkpoints_to_request));
                    }
                }
                Message::GetCheckpoints(checkpoints) => {
                    debug!("Asked for {} checkpoints", checkpoints.len());
                    let mut cps = vec![];
                    for checkpoint in checkpoints {
                        match self.checkpointdb.get_encoded(&checkpoint).unwrap() {
                            None => {}
                            Some(encoded_checkpoint) => {
                                cps.push(encoded_checkpoint.to_vec());
                            }
                        }
                    }
                    peer.write(Message::Checkpoints(cps));
                }
                Message::Checkpoints(encoded_checkpoints) => {
                    debug!("Got {} checkpoints", encoded_checkpoints.len());
                    let mut hashes: Vec<H256> = vec![];
                    let mut checkpoints: Vec<Checkpoint> = vec![];
                    for encoded_checkpoint in encoded_checkpoints {
                        let checkpoint: Checkpoint = bincode::deserialize(&encoded_checkpoint).unwrap();
                        let hash = checkpoint.hash();
                        let mut requested_checkpoints = self.requested_checkpoints.lock().unwrap();
                        requested_checkpoints.remove(&hash);
                        drop(requested_checkpoints);

                        let validity_check = validation::check_checkpoint_validity(&checkpoint, &self.config);
                        match validity_check {
                            BlockResult::Pass => {},
                            _ => continue,
                        }

                        let mut recent_checkpoints = self.recent_checkpoints.lock().unwrap();
                        if recent_checkpoints.contains(&hash) {
                            drop(recent_checkpoints);
                            continue;
                        }

                        recent_checkpoints.insert(hash);
                        drop(recent_checkpoints);

                        if self.checkpointdb.contains(&hash).unwrap() {
                            let mut recent_checkpoints = self.recent_checkpoints.lock().unwrap();
                            recent_checkpoints.remove(&hash);
                            drop(recent_checkpoints);
                            continue;
                        }

                        self.checkpointdb.insert_encoded(&hash, &encoded_checkpoint).unwrap();
                        let mut recent_checkpoints = self.recent_checkpoints.lock().unwrap();
                        recent_checkpoints.remove(&hash);
                        drop(recent_checkpoints);
                        hashes.push(hash);
                        checkpoints.push(checkpoint);
                    }
                    if hashes.is_empty() {
                        continue;
                    }
                    self.server
                        .broadcast(Message::NewCheckpoints(hashes.clone()));
                    
                    let mut to_process: Vec<Checkpoint> = checkpoints;
                    let mut to_request: Vec<H256> = vec![];
                    let mut context_update_sig = vec![];
                    while let Some(checkpoint) = to_process.pop() {
                        let mut buffer = self.buffer.lock().unwrap();
                        let data_availability = 
                            validation::check_checkpoint_avalibility(&checkpoint, &self.chain);
                        match data_availability {
                            BlockResult::Pass => drop(buffer),
                            BlockResult::MissingReferences(r) => {
                                debug!(
                                    "Missing {} referred blocks for checkpoint {:.8}",
                                    r.len(),
                                    checkpoint.hash(),
                                );
                                buffer.insert_checkpoint(&checkpoint, &r);
                                to_request.extend_from_slice(&r);
                                drop(buffer);
                                continue;
                            }
                            _ => unreachable!(),
                        }
                        debug!("Processing checkpoint {:.8}", checkpoint.hash());
                        self.chain.insert_checkpoint(&checkpoint).unwrap();
                        context_update_sig.push(
                            ContextUpdateSignal::NewCheckpoint
                        );
                    }
                    for sig in context_update_sig {
                        self.context_update_chan.send(sig).unwrap();
                    }
                    if !to_request.is_empty() {
                        to_request.sort();
                        to_request.dedup();
                        peer.write(Message::GetBlocks(to_request));
                    }
                }
                Message::Bootstrap(after) => {
                    debug!("Asked for all blocks after {}", &after);
                    /*
                     * TODO: recover this message
                    for batch in self.blockdb.blocks_after(&after, 500) {
                        peer.write(Message::Blocks(batch));
                    }
                    */
                }
            }
        }
    }
}
