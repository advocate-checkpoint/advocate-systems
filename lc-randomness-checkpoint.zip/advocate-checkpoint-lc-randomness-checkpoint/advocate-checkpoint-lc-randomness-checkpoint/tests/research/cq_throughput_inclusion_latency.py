import sys, getopt
import json

epoch = 5

def process_honest_data(data):
    tip = data.pop()
    block_map = {}
    for entry in data[0]:
        block_map[entry[0]] = (entry[1], entry[2], entry[3])
    
    return (block_map, tip)

def process_adv_data(data):
    return set(data)

def process_checkpoint_data(data):
    cp_map = {}
    for entry in data:
        cp_map[entry[0]] = (entry[1], entry[2], entry[3])
    return cp_map

def generate_cq(honest_data, tip, adv_data, cp_data):
    start = tip
    chain_length = 0
    honest_blocks = 0
    confirmed_size = len(cp_data) * epoch
    while start in honest_data:
        chain_length += 1
        start = honest_data[start][0]

    tracer = tip
    for i in range(chain_length, 0, -1):
        if i > confirmed_size:
            tracer = honest_data[tracer][0]
            continue
        if tracer not in adv_data:
            honest_blocks += 1
        tracer = honest_data[tracer][0]

    print("chain length:", chain_length)
    cq = honest_blocks / confirmed_size * 100
    return cq

def generate_goodtp_g_time(honest_data, tip, adv_data, cp_data):
    start = tip
    honest_blocks = 0
    generation_timestamp = []
    chain_length = 0
    confirmed_size = len(cp_data) * epoch
    while start in honest_data:
        chain_length += 1
        start = honest_data[start][0]

    tracer = tip
    for i in range(chain_length, 0, -1):
        if i > confirmed_size:
            tracer = honest_data[tracer][0]
            continue
        generation_timestamp.append(honest_data[tracer][1])
        if tracer not in adv_data:
            honest_blocks += 1
        tracer = honest_data[tracer][0]
    
    goodtp_g_time = honest_blocks / (max(generation_timestamp) - min(generation_timestamp)) * 1000
    return goodtp_g_time

def generate_goodtp_c_time(honest_data, tip, adv_data, cp_data):
    start = tip
    honest_blocks = 0
    confirmation_timestamp = []
    chain_length = 0
    confirmed_size = len(cp_data) * epoch
    while start in honest_data:
        chain_length += 1
        start = honest_data[start][0]

    tracer = tip
    for i in range(chain_length, 0, -1):
        if i > confirmed_size:
            tracer = honest_data[tracer][0]
            continue
        if honest_data[tracer][2] != 0:
            confirmation_timestamp.append(honest_data[tracer][2])
        if tracer not in adv_data:
            honest_blocks += 1
        tracer = honest_data[tracer][0]
    
    goodtp_c_time = honest_blocks / (max(confirmation_timestamp) - min(confirmation_timestamp)) * 1000
    return goodtp_c_time

def generate_inclusion_latency(honest_data, tip, adv_data, cp_data):
    start = tip
    total_delay = 0
    honest_blocks = 0
    confirmed_size = len(cp_data) * epoch
    chain_length = 0
    confirmation_timestamp = []
    while start in honest_data:
        chain_length += 1
        start = honest_data[start][0]
    
    tracer = tip
    for i in range(chain_length, 0, -1):
        if i > confirmed_size:
            tracer = honest_data[tracer][0]
            continue
        if tracer not in adv_data:
            honest_blocks += 1
            if honest_data[tracer][2] == 0:
                print(tracer)
            confirmation_timestamp.append(honest_data[tracer][2])
        if honest_data[tracer][0] not in honest_data:
            confirmation_timestamp.append(honest_data[tracer][2])
        tracer = honest_data[tracer][0]
    
    inclusion_latency = 0
    if honest_blocks == 0:
        return inclusion_latency
    
    total_delay = 0
    for i in range(len(confirmation_timestamp)-1):
        print(confirmation_timestamp[i] - confirmation_timestamp[i+1])
        total_delay += (confirmation_timestamp[i] - confirmation_timestamp[i+1])**2/2
    
    if total_delay == 0:
        return inclusion_latency
    
    return total_delay / (confirmation_timestamp[0] - confirmation_timestamp[-1]) / 1000

def generate_epoch_gap(cp_data):
    generation_timestamp = []
    for _, val in cp_data.items():
        generation_timestamp.append(val[1])
    gap = (max(generation_timestamp)-min(generation_timestamp)) / (len(generation_timestamp)-1) / 1000
    return gap


if __name__ == "__main__":
    block_metrics = ""
    adv_metrics = ""
    checkpoint_metrics = ""
    args = sys.argv[1:]
    try: 
        opts, args = getopt.getopt(args, "hb:a:c:", ["block=", "adv=", "checkpoint="])
    except:
        print("cq_throughput_inclusion_latency.py -b <block_metrics_file> -a <adv_metric_file> -c <checkpoint_metric_file>")
        sys.exit(2)
    for opt, arg in opts:
        if opt in ("-b", "--block"):
            block_metrics = arg
        elif opt in ("-a", "--adv"):
            adv_metrics = arg
        elif opt in ("-c", "--checkpoint"):
            checkpoint_metrics = arg
    
    with open(block_metrics) as f:
        honest_data = json.load(f)
    
    with open(adv_metrics) as f:
        adv_data = json.load(f)
    
    with open(checkpoint_metrics) as f:
        cp_data = json.load(f)
    
    post_process_honest_data,tip = process_honest_data(honest_data)
    post_process_adv_data = process_adv_data(adv_data)
    post_process_cp_data = process_checkpoint_data(cp_data)
    
    cq = generate_cq(post_process_honest_data, tip, post_process_adv_data, post_process_cp_data)
    goodtp_g_time = generate_goodtp_g_time(post_process_honest_data, tip, post_process_adv_data, post_process_cp_data)
    goodtp_c_time = generate_goodtp_c_time(post_process_honest_data, tip, post_process_adv_data, post_process_cp_data)
    inclusion_latency = generate_inclusion_latency(post_process_honest_data, tip, post_process_adv_data, post_process_cp_data)
    epoch_gap = generate_epoch_gap(post_process_cp_data)

    print("chain quality: ", cq, "%")
    print("good throughput by generation timestamp: ", goodtp_g_time, "blocks/s")
    print("good throughput by confirmation timestamp: ", goodtp_c_time, "blocks/s")
    print("inclusion latency: ", inclusion_latency, "s/block")
    print("Checkpoint generation gap:", epoch_gap, "s")
