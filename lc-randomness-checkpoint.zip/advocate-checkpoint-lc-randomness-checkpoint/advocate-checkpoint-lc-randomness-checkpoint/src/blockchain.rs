extern crate rand;

use bincode::serialize;
use crate::block::Block;
use crate::checkpoint::Checkpoint;
use crate::crypto::hash::{H256, Hashable};
use either::*;
use log::info;
use rand::Rng;
use std::collections::{HashMap, HashSet};
use std::thread;
use std::time::{SystemTime, Duration};

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum BlockResult {
    GetBlock,
    ReceivedBlocks,
    DropBlock,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum CheckpointResult {
    GetBlock,
    ReceivedCheckpoint,
    DropCheckpoint,
}


#[derive(Clone, Debug)]
pub struct BlockMessage {
    pub message_type: BlockResult,
    pub blockhashes: Option<Vec<H256>>,
    pub checkpoints: Option<Vec<H256>>,
}

#[derive(Clone, Debug)]
pub struct CheckpointMessage {
    pub message_type: CheckpointResult,
    pub checkpoint: Option<H256>,
    pub blockhash: Option<H256>,
}


// TODO:
// Add latest checkpoint information
pub struct Blockchain {
    chain: HashMap<H256, Block>,
    heights: HashMap<H256, u64>,
    children_map: HashMap<H256, Vec<H256>>,
    checkpoint_chain: HashMap<H256, Checkpoint>,
    latest_checkpoint: Checkpoint,
    tip: H256,
    adv_tip: H256,
    orphan: Orphan,
    e: u64,
    k1: u64,
    k2: u64,
    checkpoint_node: u64, 
    adv: u64, 
    cp_delay: u64,
    avg_block_delay: (u64, u64),
    pause_cp_generation: bool,
    test_highest_block: H256,
    block_metrics: HashMap<H256, (u128, u128)>,
    checkpoint_metrics: HashMap<H256, (u128, u128)>,
    adv_metrics: HashSet<H256>,
}


pub struct Orphan {
    checkpoint: HashMap<H256, Checkpoint>,
    buffer: HashMap<H256, Vec<Block>>,
    parent_map: HashMap<H256, H256>,
}


impl Blockchain {
    /// Create a new blockchain, only containing the genesis block
    pub fn new(e: u64, k1: u64, k2: u64, checkpoint_node: u64, adv: u64, cp_delay: u64) -> Self {
        let mut the_chain = Blockchain {
            chain: HashMap::new(),
            heights: HashMap::new(),
            children_map: HashMap::new(),
            tip: [0; 32].into(),
            adv_tip: [0; 32].into(),
            checkpoint_chain: HashMap::new(),
            latest_checkpoint: Checkpoint::default(),
            e: e,
            k1: k1,
            k2: k2,
            checkpoint_node: checkpoint_node,
            adv: adv,
            cp_delay: cp_delay,
            orphan: Orphan {
                checkpoint: HashMap::new(),
                buffer: HashMap::new(),
                parent_map: HashMap::new(),
            },
            avg_block_delay: (0, 0),
            pause_cp_generation: false,
            test_highest_block: [0; 32].into(),
            block_metrics: HashMap::new(),
            checkpoint_metrics: HashMap::new(),
            adv_metrics: HashSet::new(),
        };
        let genesis = Block::genesis();
        let genesis_hash = genesis.hash();
        let checkpoint = Checkpoint::create_genesis_checkpoint(genesis_hash);
        the_chain.tip = genesis_hash;
        the_chain.adv_tip = genesis_hash;
        the_chain.test_highest_block = genesis_hash;
        the_chain.latest_checkpoint = checkpoint.clone();

        the_chain.chain.insert(genesis_hash, genesis);
        the_chain.heights.insert(genesis_hash, 0);
        the_chain.checkpoint_chain.insert(checkpoint.hash(), checkpoint);
        
        the_chain
    }

    pub fn new_with_difficulty(e: u64, k1: u64, k2: u64, checkpoint_node: u64, adv: u64, cp_delay: u64, difficulty:H256) -> Self {
        let mut the_chain = Blockchain {
            chain: HashMap::new(),
            heights: HashMap::new(),
            children_map: HashMap::new(),
            tip: [0; 32].into(),
            adv_tip: [0; 32].into(),
            checkpoint_chain: HashMap::new(),
            latest_checkpoint: Checkpoint::default(),
            e: e,
            k1: k1,
            k2: k2,
            checkpoint_node: checkpoint_node,
            adv: adv,
            cp_delay: cp_delay,
            orphan: Orphan {
                checkpoint: HashMap::new(),
                buffer: HashMap::new(),
                parent_map: HashMap::new(),
            },
            avg_block_delay: (0, 0),
            pause_cp_generation: false,
            test_highest_block: [0; 32].into(),
            block_metrics: HashMap::new(),
            checkpoint_metrics: HashMap::new(),
            adv_metrics: HashSet::new(),
        };
        let genesis = Block::genesis_with_difficulty(difficulty);
        let genesis_hash = genesis.hash();
        let checkpoint = Checkpoint::create_genesis_checkpoint(genesis_hash);

        the_chain.tip = genesis_hash;
        the_chain.adv_tip = genesis_hash;
        the_chain.test_highest_block = genesis_hash;
        the_chain.latest_checkpoint = checkpoint.clone();

        the_chain.chain.insert(genesis_hash, genesis);
        the_chain.heights.insert(genesis_hash, 0);
        the_chain.checkpoint_chain.insert(checkpoint.hash(), checkpoint);
        
        the_chain
    }

    /* ---- Verification Functions ---- */
    /* Check duplicates in orphan buffer and current block chain */
    fn check_duplicate_block(&self, block: &Block) -> bool {
        let hash = block.hash();
        if self.chain.contains_key(&hash) 
        || self.orphan.parent_map.contains_key(&hash) {
            return true;
        } 
        false
    }

    /* Cehck duplicate checkpoint in orphan buffer and current checkpoint chain */
    fn check_duplicate_checkpoint(&self, checkpoint: &Checkpoint) -> bool {
        if self.checkpoint_chain.contains_key(&checkpoint.hash()) 
        || self.orphan.checkpoint.contains_key(&checkpoint.get_block()) {
            return false;
        } 
        true
    }

    /* Check difficulty */
    fn check_difficulty(&self, block: &Block) -> bool {
        let hash = block.hash();
        if hash <= block.get_difficulty() {
            return true;
        }
        false
    }


    /* Check checkpoint signature */ 
    fn check_signature(&self, block: &Block) -> bool {
        /* if signature is present, verify it. Otherwise, give a pass*/
        match block.get_checkpoint() {
            None => true,
            Some(v) => {
                if v.verify_signature().is_ok() {
                    return true;
                }
                info!("{:?}", v.verify_signature().unwrap_err());
                false
            }
        }
    }

    /* Check if the parent block is in the chain */
    fn check_parent(&self, block: &Block) -> bool {
        if self.chain.contains_key(&block.get_parent()) {
            return true;
        }
        false
    }

    /* Check if the checkpoint in the block, if not none, is included in our checkpoint chain */
    fn check_unseen_checkpoint(&self, block: &Block) -> bool {

        match block.get_checkpoint() {
            None => false,
            Some(v) => {
                if self.checkpoint_chain.contains_key(&v.hash()) {
                    return false;
                }
                true
            }
        }
    }

    /* Check if the block is tip block */
    /* 
        Here, tip block refers to: 
        1. highest height
        2. extending from the latest checkpoint
    */
    fn check_tip_block(&self, block: &Block) -> bool {

        // compare with current tip height and inserted block height
        let block_height = self.heights.get(&block.hash()).unwrap();
        let tip_block_height = self.heights.get(&self.tip).unwrap();
        if block_height <= tip_block_height {
            return false;
        }
        
        // trace through inserted block height - latest checkpoint block height to see if 
        // it is extended from latest checkpoint block
        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap();
        let mut parent = block.hash();
        for _ in 0..(block_height-checkpoint_block_height) {
            parent = self.chain.get(&parent).unwrap().get_parent();
        }
        if parent == self.latest_checkpoint.get_block() {
            return true;
        }
        false
    }

    fn check_tip_block_adv(&self, block: &Block) -> bool {

        // compare with current tip height and inserted block height
        let block_height = self.heights.get(&block.hash()).unwrap();
        let tip_block_height = self.heights.get(&self.adv_tip).unwrap();
        if block_height <= tip_block_height {
            return false;
        }
        
        // trace through inserted block height - latest checkpoint block height to see if 
        // it is extended from latest checkpoint block
        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap();
        let mut parent = block.hash();
        for _ in 0..(block_height-checkpoint_block_height) {
            parent = self.chain.get(&parent).unwrap().get_parent();
        }
        if parent == self.latest_checkpoint.get_block() {
            return true;
        }
        false
    }

    /* Check whether the distance between inserted block and latest checkpoint is bigger than K2 */
    // ruiyang: should the latest checkpoint be contained in the block?
    fn check_k2_distance(&self, block: &Block) -> bool {
        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap();
        let block_height = self.heights.get(&block.hash()).unwrap();
        if block_height - checkpoint_block_height >= self.k2 {
            return true;
        }
        false 
    }

    /* Check whether there is a block with the latest checkpoint in its header within K1~K2 distance */
    fn check_checkpoint_k1_k2(&self, block: &Block) -> bool {
        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap();
        let block_height = self.heights.get(&block.hash()).unwrap();
        
        /* trace back to latest checkpoint height + K2 */
        let mut parent = block.hash();
        for _ in 0..(block_height-checkpoint_block_height-self.k2) {
            parent = self.chain.get(&parent).unwrap().get_parent();
        }

        /* iterate check through latest checkpoint height + (K1, K2] */
        let mut ancestor_block = self.chain.get(&parent).unwrap();
        for _ in 0..(self.k2-self.k1) {
            match ancestor_block.get_checkpoint() {
                None => {
                    parent = ancestor_block.get_parent();
                    ancestor_block = self.chain.get(&parent).unwrap();
                },
                Some(v) => {
                    if v != self.latest_checkpoint {
                        return false;
                    } else {
                        return true;
                    }
                }
            }
        }
        false
    }

    /* Check whether block is found for orphan checkpoint */
    fn check_orphan_checkpoint(&self, blockhash: H256) -> bool {
        return self.orphan.checkpoint.contains_key(&blockhash);
    }
    
    /* Check whether current node is checkpoint node or normal mining node */
    fn check_checkpoint_node(&self) -> bool {
        !(self.checkpoint_node == 0)
    }

    /* Check whether the distance between the inserted block and latest checkpoint block has reached E */
    fn check_e_distance(&self, block: &Block) -> bool {
        let block_height = self.heights.get(&block.hash()).unwrap();
        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap();
        block_height - checkpoint_block_height > self.e
    }

    /* Check whether the distance between the inserted block and latest checkpoint block has >= E+K1 */
    fn check_eplusk1_distance(&self, block: &Block) -> bool {
        let block_height = self.heights.get(&block.hash()).unwrap();
        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap();
        block_height - checkpoint_block_height >= self.e+self.k1
    }

    /* Check whether the distance between the inserted block and latest checkpoint block has >= 2E */
    fn check_2e_distance(&self, block: &Block) -> bool {
        let block_height = self.heights.get(&block.hash()).unwrap();
        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap();
        block_height - checkpoint_block_height >= 2 * self.e
    }
    
    /* Check whether next block is located within (K1, K2] distance from latest checkpoint used by miner */
    pub fn check_k1_k2_distance(&self) -> bool {
        let mut next_height = self.heights.get(&self.tip).unwrap() + 1;
        if self.adv != 0 {
            next_height = self.heights.get(&self.adv_tip).unwrap() + 1;
        }
        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap() + 0;
        let difference = next_height - checkpoint_block_height;
        self.k1 < difference && difference <= self.k2
    }

    /* Check whether the block appears within (K1, K2] from its checkpoint if it has one */
    fn check_k1_k2_distance_block(&self, block: &Block) -> bool {
        if block.contains_checkpoint() {
            let block_checkpoint = block.get_checkpoint().unwrap();
            let checkpoint_block_height = self.heights.get(&block_checkpoint.get_block()).unwrap()+0;
            let block_height = self.heights.get(&block.get_parent()).unwrap()+1;
            let height_diff = block_height-checkpoint_block_height;
            return (height_diff > self.k1) && (height_diff <= self.k2);
        } else {
            return true;
        }
    }


    /* Check existence for incoming checkpoint hashes from messagener */
    pub fn check_checkpoint_existence(&self, checkpoint_hash: &H256) -> bool {
        if self.checkpoint_chain.contains_key(checkpoint_hash) {
            return true;
        }
        for (_, val) in self.orphan.checkpoint.iter() {
            if *checkpoint_hash == val.hash() {
                return true;
            }
        }
        false
    }

    /* Live Testing 1 */
    /* Check tip in longest chain manner */
    pub fn check_test_tip(&self, block: &Block) -> bool {
        // compare with current tip height and inserted block height
        let block_height = self.heights.get(&block.hash()).unwrap();
        let tip_block_height = self.heights.get(&self.test_highest_block).unwrap();
        return block_height > tip_block_height;
    }
    /* Live Testing 1 */

    /* ---- Action Functions ---- */
    fn insert_orphan_buffer(&mut self, block: &Block) {
        if self.orphan.buffer.contains_key(&block.get_parent()) {
            let parent_vec = self.orphan.buffer.get_mut(&block.get_parent()).unwrap();
            parent_vec.push(block.clone());
        } else {
            self.orphan.buffer.insert(block.get_parent(), vec![block.clone()]);
        }
        self.orphan.parent_map.insert(block.hash(), block.get_parent());
    }

    fn insert_blockchain(&mut self, block: &Block) {
        // update block metrics
        self.block_metrics.insert(block.hash(), (block.header.timestamp, 0));

        let block_height = self.heights.get(&block.get_parent()).unwrap() + 1;
        self.chain.insert(block.hash(), block.clone());
        self.heights.insert(block.hash(), block_height);
        if self.children_map.contains_key(&block.get_parent()) {
            self.children_map.get_mut(&block.get_parent()).unwrap().push(block.hash());
        } else {
            self.children_map.insert(block.get_parent(), vec![block.hash()]);
        }
    }

    pub fn update_tip_block_during_checkpoint_update(&mut self) {

        // siheng: Optimization needed to search for targeted tip block
        let tip_block_height = self.heights.get(&self.tip).unwrap() + 0;
        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap()+0;

        // Step 1: check if current tip block is extended from new checkpoint block
        let mut parent = self.tip;
        for _ in 0..(tip_block_height-checkpoint_block_height) {
            parent = self.chain.get(&parent).unwrap().get_parent();
        }
        if parent == self.latest_checkpoint.get_block() {
            // Step 2a: if current tip is extended from new checkpoint block but the difference is over K2, 
            // then shrink the tip to K2 - 1
            if tip_block_height >= checkpoint_block_height + self.k2 {
                let mut tmp = self.tip;
                for _ in 0..(tip_block_height-checkpoint_block_height-self.k2+1) {
                    tmp = self.chain.get(&tmp).unwrap().get_parent();
                }
                // let entry = self.block_metrics.get_mut(&tmp).unwrap();
                // entry.1 = get_time();
                self.tip = tmp;
            }
        } else {
            
            let mut tip_tracer = parent;
            let mut cp_tracer = self.latest_checkpoint.get_block();
            for _ in 0..self.e {
                if tip_tracer == cp_tracer {
                    break;
                } else {
                    let cp_tracer_info = self.block_metrics.get_mut(&cp_tracer).unwrap();
                    cp_tracer_info.1 = get_time();
                    tip_tracer = self.chain.get(&tip_tracer).unwrap().get_parent();
                    cp_tracer = self.chain.get(&cp_tracer).unwrap().get_parent();
                }
            }

            // Step 2b: if current tip is not extended from new checkpoint block. We will need to search for
            // Min(K2-1, blocks that extends most from new checkpoint block)

            // potential_leaves means current same-level blocks extend from checkpoint block(including itself)
            let mut potential_leaves: Vec<H256> = vec![self.latest_checkpoint.get_block()];
            for _ in 0..(self.k2-1) {
                let mut tmp_block_buffer: Vec<H256> = Vec::new();
                for potential_leaf in potential_leaves.iter() {
                    match self.children_map.get(potential_leaf) {
                        None => continue,
                        Some(v) => {
                            tmp_block_buffer.append(&mut v.clone());
                        }
                    }
                }
                if tmp_block_buffer.is_empty() {
                    let mut tracer = potential_leaves[0];
                    let potential_leaf_height = self.heights.get(&tracer).unwrap()+0;
                    for _ in 0..(potential_leaf_height-checkpoint_block_height) {
                        let entry = self.block_metrics.get_mut(&tracer).unwrap();
                        entry.1 = get_time();
                        tracer = self.chain.get(&tracer).unwrap().get_parent();
                    }
                    self.tip = potential_leaves[0];
                    return;
                } else {
                    potential_leaves = tmp_block_buffer;
                }
            }
            let mut tracer = potential_leaves[0];
            let potential_leaf_height = self.heights.get(&tracer).unwrap()+0;
            for _ in 0..(potential_leaf_height-checkpoint_block_height) {
                let entry = self.block_metrics.get_mut(&tracer).unwrap();
                entry.1 = get_time();
                tracer = self.chain.get(&tracer).unwrap().get_parent();
            }
            self.tip = potential_leaves[0];
        }
    }

    pub fn update_adv_tip_block_during_checkpoint_update(&mut self) {

        let adv_tip_block_height = self.heights.get(&self.adv_tip).unwrap() + 0;
        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap()+0;
        
        if self.adv_metrics.contains(&self.latest_checkpoint.get_block()) {
            // Step 1: check if current tip block is extended from new checkpoint block
            let mut parent = self.adv_tip;
            for _ in 0..(adv_tip_block_height-checkpoint_block_height) {
                parent = self.chain.get(&parent).unwrap().get_parent();
            }
            if parent == self.latest_checkpoint.get_block() {
                // Step 2a: if current tip is extended from new checkpoint block but the difference is over K2, 
                // then shrink the tip to K2 - 1
                if adv_tip_block_height >= checkpoint_block_height + self.k2 {
                    info!("adv tip is: {}", adv_tip_block_height);
                    let mut tmp = self.adv_tip;
                    for _ in 0..(adv_tip_block_height-checkpoint_block_height-self.k2+1) {
                        tmp = self.chain.get(&tmp).unwrap().get_parent();
                    }
                    let tmp_block_height = self.heights.get(&tmp).unwrap() + 0;
                    info!("Reset adv tip to: {}", tmp_block_height);
                    self.adv_tip = tmp;
                }
            } else {
                // Step 2b: if current tip is not extended from new checkpoint block. We will need to search for
                // Min(K2-1, blocks that extends most from new checkpoint block)

                // potential_leaves means current same-level blocks extend from checkpoint block(including itself)
                let mut potential_leaves: Vec<H256> = vec![self.latest_checkpoint.get_block()];
                for _ in 0..(self.k2-1) {
                    let mut tmp_block_buffer: Vec<H256> = Vec::new();
                    for potential_leaf in potential_leaves.iter() {
                        match self.children_map.get(potential_leaf) {
                            None => continue,
                            Some(v) => {
                                for block in v.iter() {
                                    if self.adv_metrics.contains(block) {
                                        tmp_block_buffer.push(*block);
                                    }
                                }
                            }
                        }
                    }
                    if tmp_block_buffer.is_empty() {
                        let entry = self.block_metrics.get_mut(&potential_leaves[0]).unwrap();
                        entry.1 = get_time();
                        self.adv_tip = potential_leaves[0];
                        return;
                    } else {
                        potential_leaves = tmp_block_buffer;
                    }
                }
                let entry = self.block_metrics.get_mut(&potential_leaves[0]).unwrap();
                entry.1 = get_time();
                self.adv_tip = potential_leaves[0];
            }
        } else {
            self.adv_tip = self.tip;
        }
    }


    fn update_tip_block(&mut self, blockhash: H256) {
        // Update block metrics
        let tip_height = self.heights.get(&self.tip).unwrap()+0;
        let block_height = self.heights.get(&blockhash).unwrap()+0;

        let mut block_tracer = blockhash;
        for _ in 0..(block_height - tip_height) {
            let block_tracer_info = self.block_metrics.get_mut(&block_tracer).unwrap();
            block_tracer_info.1 = get_time();
            block_tracer = self.chain.get(&block_tracer).unwrap().get_parent();
        }
        if block_tracer != self.tip {
            let mut tip_tracer = self.tip;
            let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap() + 0;
            for _ in 0..(tip_height - checkpoint_block_height) {
                if tip_tracer == block_tracer {
                    break;
                } else {
                    let block_tracer_info = self.block_metrics.get_mut(&block_tracer).unwrap();
                    block_tracer_info.1 = get_time();
                    tip_tracer = self.chain.get(&tip_tracer).unwrap().get_parent();
                    block_tracer = self.chain.get(&block_tracer).unwrap().get_parent();
                }
            }
        }

        self.tip = blockhash;
    }

    /* return the latest candidate checkpoint block*/
    fn get_latest_candidate_checkpoint_block(&self, block: &Block) -> H256 {
        let block_height = self.heights.get(&block.hash()).unwrap();
        let next_checkpoint_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap() + self.e;
        
        /* trace back to candidate checkpoint block */
        let mut parent = block.hash();
        for _ in 0..(block_height-next_checkpoint_height) {
            parent = self.chain.get(&parent).unwrap().get_parent();
        }
        return parent;
    }

    /*  ---- Functions that are used in public */
    pub fn receive_block(&mut self, block: &Block) -> BlockMessage {
        if self.check_duplicate_block(block)
        || !self.check_difficulty(block)
        || !self.check_signature(block) {
            // info!("Drop: {}", block.hash());
            // info!("Drop cuz duplicate: {}", self.check_duplicate_block(block));
            // info!("Drop cuz difficulty: {}", self.check_difficulty(block));
            // info!("Drop cuz signature: {}", self.check_signature(block));
            return BlockMessage {
                message_type: BlockResult::DropBlock,
                blockhashes: None,
                checkpoints: None,
            };
        } 
        if !self.check_parent(block) {
            // info!("received parent: {}", block.get_parent());
            self.insert_orphan_buffer(block);
            return BlockMessage {
                message_type: BlockResult::GetBlock,
                blockhashes: Some(vec![block.get_parent()]),
                checkpoints: None,
            };
        } else {
            // We are going to handle incoming block as well as its possible children in orphan buffer together
            let mut received_blocks: Vec<H256> = Vec::new();
            let mut received_checkpoints: Vec<H256> = Vec::new();
            let mut block_stacks: Vec<Block> = Vec::new();

            block_stacks.push(block.clone());
            while !block_stacks.is_empty() {
                let curr_block = block_stacks.pop().unwrap();
                if !self.check_k1_k2_distance_block(&curr_block) {
                    // info!("problem!");
                    /* siheng: it is possible to generate empty ReceiveBlock msg here */
                    continue;
                }
                
                self.insert_blockchain(&curr_block);
                // info!("{}:{}", curr_block.hash(), self.heights.get(&curr_block.hash()).unwrap()+0);
                if self.check_unseen_checkpoint(&curr_block) {
                    let unseen_checkpoint = curr_block.get_checkpoint().unwrap();
                    // update checkpoint
                    self.checkpoint_chain.insert(
                        unseen_checkpoint.hash(), 
                        unseen_checkpoint.clone()
                    );
                    self.checkpoint_metrics.insert(
                        unseen_checkpoint.hash(), 
                        (unseen_checkpoint.timestamp, get_time()),
                    );
                    self.latest_checkpoint = unseen_checkpoint;
                    self.update_tip_block_during_checkpoint_update();
                    if self.adv != 0 {
                        self.update_adv_tip_block_during_checkpoint_update();
                    }
                    // collect checkpoint
                    received_checkpoints.push(self.latest_checkpoint.hash());
                }
                if self.check_orphan_checkpoint(curr_block.hash()) {
                    let orphan_checkpoint = self.orphan.checkpoint.remove(&curr_block.hash()).unwrap();
                    self.checkpoint_metrics.insert(
                        orphan_checkpoint.hash(), 
                        (orphan_checkpoint.timestamp, get_time()),
                    );
                    let entry = self.block_metrics.get_mut(&curr_block.hash()).unwrap();
                    entry.1 = get_time();
                    self.latest_checkpoint = orphan_checkpoint;
                    self.tip = curr_block.hash();
                    self.adv_tip = curr_block.hash();
                }
                /* Live Testing 1 */
                if self.check_test_tip(&curr_block) {
                    self.test_highest_block = curr_block.hash();
                }
                /* Live Testing 1 */
                if self.adv == 0 {
                    received_blocks.push(curr_block.hash());
                    if self.check_tip_block(&curr_block) {
                        if !self.check_k2_distance(&curr_block) || self.check_checkpoint_k1_k2(&curr_block) {
                            self.update_tip_block(curr_block.hash());
                            if self.check_checkpoint_node() && !self.pause_cp_generation {
                                // generate checkpoint
                                if self.check_eplusk1_distance(&curr_block) {
                                    let mut next_checkpoint_block_hash = self.tip;
                                    if !self.check_2e_distance(&curr_block) {
                                        next_checkpoint_block_hash = 
                                            self.get_latest_candidate_checkpoint_block(&curr_block);
                                    }
                                    
                                    let mut rng = rand::thread_rng();
                                    let mut new_checkpoint = Checkpoint::new(
                                        next_checkpoint_block_hash,
                                        rng.gen::<u32>(),
                                        self.latest_checkpoint.get_sequence()+1,
                                    );
                                    if self.cp_delay != 0 {
                                        let interval = Duration::from_micros(self.cp_delay);
                                        thread::sleep(interval);
                                    }
                                    let new_sig = new_checkpoint.generate_signature().unwrap();
                                    new_checkpoint.set_sig(new_sig);
                                    self.checkpoint_metrics.insert(
                                        new_checkpoint.hash(), 
                                        (new_checkpoint.timestamp, get_time()),
                                    );
                                    // update latest checkpoint
                                    self.checkpoint_chain.insert(new_checkpoint.hash(), new_checkpoint.clone());
                                    self.latest_checkpoint = new_checkpoint;
                                    // collect received checkpoint
                                    received_checkpoints.push(self.latest_checkpoint.hash());
                                } 
                            }
                        } else {
                            // TODO: not sure if it is needed as the flowchart comments
                        }
                    }
                } else {
                    if !self.adv_metrics.contains(&curr_block.hash()) {
                        received_blocks.push(curr_block.hash());
                        if self.check_tip_block(&curr_block) {
                            if !self.check_k2_distance(&curr_block) || self.check_checkpoint_k1_k2(&curr_block) {
                                self.update_tip_block(curr_block.hash());
                            }
                        }
                    }else {
                        if self.check_tip_block_adv(&curr_block) {
                            if !self.check_k2_distance(&curr_block) || self.check_checkpoint_k1_k2(&curr_block) {
                                self.adv_tip = curr_block.hash();
                            }
                        }
                        let adv_tip_block_height = self.heights.get(&self.adv_tip).unwrap()+0;
                        let checkpoint_block_height = self.heights.get(&self.latest_checkpoint.get_block()).unwrap()+0;
                        let tip_block_height = self.heights.get(&self.tip).unwrap()+0;
                        info!("Each Update at adv tip: {}, tip: {}, cp heights: {}", adv_tip_block_height, tip_block_height, checkpoint_block_height);
                        if adv_tip_block_height == checkpoint_block_height + self.e {
                            let mut tracer = self.adv_tip;
                            for _ in 0..self.e {
                                received_blocks.push(tracer);
                                tracer = self.chain.get(&tracer).unwrap().get_parent();
                            }
                            self.tip = self.adv_tip;
                        }
                    }
                }
                // Find children in orphan and update orphan buffer
                match self.orphan.buffer.get(&curr_block.hash()) {
                    None => {},
                    Some(v) => {
                        for child in v.iter() {
                            block_stacks.push(child.clone());
                            self.orphan.parent_map.remove(&child.hash());
                        }
                        self.orphan.buffer.remove(&curr_block.hash());
                    }
                }
            }
            return BlockMessage {
                message_type: BlockResult::ReceivedBlocks,
                blockhashes: Some(received_blocks),
                checkpoints: Some(received_checkpoints),
            }
        }
    } 

    pub fn receive_checkpoint(&mut self, checkpoint: &Checkpoint ) -> CheckpointMessage {

        // checkpoint duplicate and validity check
        if !self.check_duplicate_checkpoint(&checkpoint) 
        || !checkpoint.verify_signature().is_ok() {
            return CheckpointMessage {
                message_type: CheckpointResult::DropCheckpoint,
                checkpoint: None,
                blockhash: None,
            };
        } 

        // Check if referred block is in the chain
        if !self.chain.contains_key(&checkpoint.get_block()) {
            // There is two types of result, if referred block is in the orphan, we are not 
            // going to broadcast any messages(siheng: there is another implementation by look for very missing block)
            self.orphan.checkpoint.insert(checkpoint.get_block(), checkpoint.clone());
            if self.orphan.parent_map.contains_key(&checkpoint.get_block()) {
                return CheckpointMessage {
                    message_type: CheckpointResult::DropCheckpoint,
                    checkpoint: None,
                    blockhash: None,
                };
            } else {
                return CheckpointMessage {
                    message_type: CheckpointResult::GetBlock,
                    checkpoint: None,
                    blockhash: Some(checkpoint.get_block()),
                };
            }
        }
        self.latest_checkpoint = checkpoint.clone();
        self.checkpoint_chain.insert(checkpoint.hash(), checkpoint.clone());
        // Update checkpoint metrics
        self.checkpoint_metrics.insert(checkpoint.hash(), (checkpoint.timestamp, get_time()));
        self.update_tip_block_during_checkpoint_update();
        if self.adv != 0 {
            self.update_adv_tip_block_during_checkpoint_update();
        }
        return CheckpointMessage {
            message_type: CheckpointResult::ReceivedCheckpoint,
            checkpoint: Some(checkpoint.hash()),
            blockhash: None,
        };
    }

    /// Update the averge block relay given the list of timestamp
    pub fn update_block_avg_relay(& mut self, timestamps: &Vec<u64>, now: u64) {

        for timestamp in timestamps.iter() {
            self.avg_block_delay = (self.avg_block_delay.0+now-timestamp, self.avg_block_delay.1+1);
        }
    }

    /// Get the last block's hash of the longest chain
    pub fn tip(&self) -> H256 {
        if self.adv == 0 {
            self.tip
        } else {
            self.adv_tip
        }
        
    }

    /// Get orphan block number 
    pub fn orphan_size(&self) -> u64 {
        self.orphan.parent_map.len() as u64
    }

    /// Get entire blocks size
    pub fn blocks_size_bytes(&self) -> u64 {
        let mut blocks: Vec<Block> = Vec::new();

        for (_,v) in self.chain.iter() {
            blocks.push(v.clone());
        }

        for (_,v) in self.orphan.buffer.iter() {
            for vi in v.iter() {
                blocks.push(vi.clone());
            }
            
        }
        serialize(&blocks).unwrap().len() as u64
    }

    /// Get average block relay 
    pub fn get_avg_block_relay(&self) -> u64 {
        self.avg_block_delay.0 / self.avg_block_delay.1
    }

    /// Get all of the block's hash of the longest chain from tip to genesis
    #[cfg(any(test, test_utilities))]
    pub fn all_blocks_in_longest_chain(&self) -> Vec<H256> {
        let mut result: Vec<H256> = Vec::new();

        let mut start_block = self.chain.get(&self.tip).unwrap();
        while start_block.get_parent() != ([0; 32].into()) {
            result.push(start_block.hash());
            start_block = self.chain.get(&start_block.get_parent()).unwrap();
        }
        result
    }
    
    /// Get the block diffculty 
    pub fn get_difficulty(&self, block_hash: &H256) -> H256 {
        self.chain.get(block_hash).unwrap().get_difficulty()
    }

    /// Get existing blocks in the chain
    pub fn select_blocks(&self, block_hashes: &Vec<H256>) -> Vec<Block> {
        let mut founded_blocks: Vec<Block> = Vec::new();

        for the_hash in block_hashes.iter() {
            if self.chain.contains_key(&the_hash) {
                founded_blocks.push(self.chain.get(&the_hash).unwrap().clone());
            } else if self.orphan.parent_map.contains_key(&the_hash) {
                let parent_hash = self.orphan.parent_map.get(&the_hash).unwrap();
                
                for the_block in self.orphan.buffer.get(&parent_hash).unwrap().iter() {
                    if the_block.hash() == *the_hash {
                        founded_blocks.push(the_block.clone());
                    }
                }
            }
        }
        founded_blocks
    }

    /// Get unfound hashes in the chain based on blocks
    pub fn select_unfound_hashes(&self, blocks: &Vec<Block>) -> Vec<H256> {
        let mut unfound_hashes: Vec<H256> = Vec::new();

        for the_block in blocks.iter() {
            if !self.chain.contains_key(&the_block.hash()) && 
            !self.orphan.parent_map.contains_key(&the_block.hash()) {
                unfound_hashes.push(the_block.hash());
            }
        }
        unfound_hashes
    }

    /// Get unfound hashes in the chain based on blocks
    pub fn select_unfound_timestamp(&self, blocks: &Vec<Block>) -> Vec<u128> {
        let mut unfound_timestamp: Vec<u128> = Vec::new();

        for the_block in blocks.iter() {
            if !self.chain.contains_key(&the_block.hash()) && 
            !self.orphan.parent_map.contains_key(&the_block.hash()) {
                unfound_timestamp.push(the_block.get_timestamp());
            }
        }
        unfound_timestamp
    }


    /// Get orphan block parents hashes from list of blocks 
    pub fn select_orphan_parent_hash(&self, blocks: &Vec<Block>) -> Vec<H256> {
        let mut parents: Vec<H256> = Vec::new();
        for the_block in blocks.iter() {
            let block_parent = the_block.get_parent();
            if self.orphan.parent_map.contains_key(&the_block.hash()) {
                parents.push(block_parent);
            }
        }
        parents
    }

    /// Get unfound hashes in the chain based on hashes
    pub fn check_blocks_existence(&self, block_hashes: &Vec<H256>) -> Vec<H256> {
        let mut result: Vec<H256> = Vec::new();
        for the_hash in block_hashes.iter() {
            // check blocks in the chain or in orphan buffer
            if !self.chain.contains_key(&the_hash) && !self.orphan.parent_map.contains_key(&the_hash){
                result.push(the_hash.clone());
            }
        }
        result
    }

    /* Set pause checkpoint generation flag */
    pub fn set_pause_cp_generation(&mut self, flag: bool) {
        self.pause_cp_generation = flag;
    }

    /* Set latest checkpoint into block*/
    pub fn set_latest_checkpoint(&self, block: &mut Block) {
        block.set_checkpoint(self.latest_checkpoint.clone());
    }

    /* Update the adversarial blocks metrics */
    pub fn update_adv_metrics(&mut self, block_hash: H256) {
        self.adv_metrics.insert(block_hash);
    }

    /* Get a list of checkpoints requested from messager */
    pub fn get_messager_checkpoints(&self, checkpoints: &Vec<H256>) -> Vec<Checkpoint> {
        let mut requested_checkpoints: Vec<Checkpoint> = Vec::new();
        for checkpoint in checkpoints.iter() {
            match self.checkpoint_chain.get(checkpoint) {
                None => {
                    for (_, v) in self.orphan.checkpoint.iter() {
                        if *checkpoint == v.hash() {
                            requested_checkpoints.push(v.clone());
                            break;
                        }
                    }
                },
                Some(v) => {
                    requested_checkpoints.push(v.clone());
                }
            }
        }
        requested_checkpoints
    }

    /* Get the current chain length */
    pub fn get_chain_length(&self) -> u64 {
        self.heights.get(&self.tip).unwrap()+1
    }

    /* Get total chain size */
    pub fn chain_size(&self) -> u64 {
        self.chain.len() as u64
    }

    /* ---- Test utility functions ---- */
    pub fn test_get_latest_checkpoint(&self) -> Checkpoint {
        self.latest_checkpoint.clone()
    }

    pub fn test_print_orphan_information(&self) {
        info!("Orphan buffer: ");
        for (k, v) in self.orphan.parent_map.iter() {
            info!("child: {}", *k);
            info!("parent: {}", *v);
        }
    }

    pub fn test_print_block_in_chain(&self) {
        info!("Blockchain: ");
        for (k, v) in self.chain.iter() {
            info!("child: {}", *k);
            info!("parent: {}", v.get_parent());
        }
    }

    pub fn test_print_longest_checkpoint_chain(&self) {
        info!("Longest Checkpoint Chain: ");
        let mut the_block = self.chain.get(&self.tip).unwrap();
        loop {
            info!("hash: {}", the_block.hash());
            if the_block.contains_checkpoint() {
                info!("cp: {}", the_block.get_checkpoint().unwrap().hash());
            }
            let height = self.heights.get(&the_block.hash()).unwrap()+0;
            info!("height: {}", height);
            if height == 0 {
                break;
            } else {
                the_block = self.chain.get(&the_block.get_parent()).unwrap();
            }
        }   
    }


    pub fn test_get_block_metrics(&self) -> Either<Vec<String>, (Vec<(String, String, u128, u128)>, String)> {
        if self.adv == 0 {
            let mut block_info: Vec<(String, String, u128, u128)> = vec![];
            for (block_hash, (generation_timestamp, confirmation_timestamp)) in self.block_metrics.iter() {
                block_info.push((
                    hex::encode(*block_hash), 
                    hex::encode(self.chain.get(block_hash).unwrap().get_parent()),
                    *generation_timestamp, 
                    *confirmation_timestamp,
                ));
            }
            // block_info.sort_by_key(|k| k.2);
            Right((block_info, hex::encode(self.tip)))
        } else {
            let mut adv_block_info: Vec<String> = vec![];
            for block_hash in self.adv_metrics.iter() {
                adv_block_info.push(hex::encode(*block_hash));
            }
            Left(adv_block_info)
        }
    }

    pub fn test_get_checkpoint_metrics(&self) -> Vec<(String, String, u128, u128)> {
        let mut checkpoint_info: Vec<(String, String, u128, u128)> = vec![];
        for (checkpoint_hash, (generation_timestamp, insertion_timestamp)) in self.checkpoint_metrics.iter() {
            checkpoint_info.push((
                hex::encode(*checkpoint_hash), 
                hex::encode(self.checkpoint_chain.get(checkpoint_hash).unwrap().get_block()),
                *generation_timestamp, 
                *insertion_timestamp
            ));
        }
        checkpoint_info
    }

    pub fn test_get_live_test_1(&self) -> (u64, u64, u64) {
        let latest_cp_height: u64 =  *self.heights.get(&self.latest_checkpoint.get_block()).unwrap();
        let latest_cp_tip: u64 = *self.heights.get(&self.tip).unwrap();
        let latest_tip: u64 = *self.heights.get(&self.test_highest_block).unwrap();
        (latest_cp_height, latest_cp_tip, latest_tip)
    }

}


/// Get the current UNIX timestamp
fn get_time() -> u128 {
    let cur_time = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH);
    match cur_time {
        Ok(v) => {
            return v.as_millis();
        }
        Err(e) => println!("Error parsing time: {:?}", e),
    }
    // TODO: there should be a better way of handling this, or just unwrap and panic
    0
}



// #[cfg(any(test, test_utilities))]
// mod tests {
//     use super::*;
//     use rand::Rng;
//     use crate::checkpoint::Checkpoint;
//     use crate::block::test::{generate_random_block,generate_random_valid_block,generate_random_block_with_checkpoint, generate_random_invalid_block};
//     use crate::crypto::hash::Hashable;

//     #[test]
//     fn insert_one() {
//         let mut difficulty_bytes = [0; 32];
//         for i in 0..32{
//             difficulty_bytes[i] = 255;
//         }
//         let mut blockchain = Blockchain::new_with_difficulty(5, 0, 3, 0, 0, difficulty_bytes.into());
//         let genesis_hash = blockchain.tip();
//         let block = generate_random_valid_block(&genesis_hash);
//         let ret = blockchain.receive_block(&block);
//         assert_eq!(blockchain.tip(), block.hash());
//         assert_eq!(ret.message_type, BlockResult::ReceivedBlocks);
//         assert_eq!(ret.blockhashes, Some(vec![block.hash()]));
//         assert_eq!(ret.checkpoints, Some(vec![]));
//     }

//     #[test]
//     fn insert_one_failed() {
//         let difficulty_bytes = [0; 32];
//         let mut blockchain = Blockchain::new_with_difficulty(5, 0, 3, 0, 0, difficulty_bytes.into());
//         let genesis_hash = blockchain.tip();
//         let block = generate_random_invalid_block(&genesis_hash);
//         let ret = blockchain.receive_block(&block);
//         assert_eq!(ret.message_type, BlockResult::DropBlock);
//     }

//     #[test]
//     fn insert_block_with_checkpoint_not_pass() {
//         let mut difficulty_bytes = [0; 32];
//         for i in 0..32{
//             difficulty_bytes[i] = 255;
//         }
//         let mut blockchain = Blockchain::new_with_difficulty(2, 0, 1, 1, 0, difficulty_bytes.into());
//         let genesis_hash = blockchain.tip();
//         let block_1 = generate_random_valid_block(&genesis_hash);
//         let block_2 = generate_random_valid_block(&block_1.hash());
//         blockchain.receive_block(&block_1);
//         let ret = blockchain.receive_block(&block_2);
//         assert_eq!(blockchain.tip(), genesis_hash);
//     }

//     #[test]
//     fn insert_block_with_checkpoint_switch() {
//         let mut difficulty_bytes = [0; 32];
//         for i in 0..32{
//             difficulty_bytes[i] = 255;
//         }
//         let mut blockchain = Blockchain::new_with_difficulty(2, 0, 1, 1, 0, difficulty_bytes.into());
//         let genesis_hash = blockchain.tip();
//         let block_1 = generate_random_block_with_checkpoint(blockchain.test_get_latest_checkpoint(), genesis_hash);
//         let block_2 = generate_random_valid_block(&block_1.hash());
//         blockchain.receive_block(&block_1);
//         let ret = blockchain.receive_block(&block_2);
//         assert_eq!(blockchain.tip(), block_2.hash());
//         assert_eq!(ret.message_type, BlockResult::ReceivedBlocks);
//         let latest_checkpoint = blockchain.test_get_latest_checkpoint();
//         assert_eq!(latest_checkpoint.get_block(), block_2.hash());
//         assert_eq!(latest_checkpoint.get_sequence(), 1);
//         assert!(latest_checkpoint.verify_signature().is_ok());
//     }


    // #[test]
    // fn complex_test_several_corner_cases() {
    //     let mut rng = rand::thread_rng();
    //     let mut difficulty_bytes = [0; 32];
    //     for i in 0..32{
    //         difficulty_bytes[i] = 255;
    //     }
    //     let mut blockchain = Blockchain::new_with_difficulty(4, 1, 2, 0, 0, difficulty_bytes.into());
    //     let genesis_checkpoint = blockchain.test_get_latest_checkpoint();
    //     // A1: check block with unseen checkpoint
    //     let genesis_hash = blockchain.tip();
    //     let block_2_1 = generate_random_valid_block(&genesis_hash);
    //     let block_2_2 = generate_random_block_with_checkpoint(blockchain.test_get_latest_checkpoint(), block_2_1.hash());
    //     let block_2_3 = generate_random_valid_block(&block_2_2.hash());
    //     let block_2_4 = generate_random_valid_block(&block_2_3.hash());
    //     let block_2_5 = generate_random_valid_block(&block_2_4.hash());
    //     let mut c1 = Checkpoint::new(block_2_4.hash(), rng.gen::<u32>(), 1);
    //     c1.set_sig(c1.generate_signature().unwrap());
    //     let block_2_6 = generate_random_block_with_checkpoint(c1, block_2_5.hash());
    //     blockchain.receive_block(&block_2_1);
    //     blockchain.receive_block(&block_2_2);
    //     blockchain.receive_block(&block_2_3);
    //     blockchain.receive_block(&block_2_4);
    //     blockchain.receive_block(&block_2_5);
    //     blockchain.receive_block(&block_2_6);
    //     assert_eq!(blockchain.tip(), block_2_6.hash());

    //     //A2: another fork from the beginning with larger height
    //     let block_1_1 = generate_random_valid_block(&genesis_hash);
    //     let block_1_2 = generate_random_block_with_checkpoint(genesis_checkpoint, block_1_1.hash());
    //     let block_1_3 = generate_random_valid_block(&block_1_2.hash());
    //     let block_1_4 = generate_random_valid_block(&block_1_3.hash());
    //     let block_1_5 = generate_random_valid_block(&block_1_4.hash());
    //     let block_1_6 = generate_random_valid_block(&block_1_5.hash());
    //     let block_1_7 = generate_random_valid_block(&block_1_6.hash());
    //     blockchain.receive_block(&block_1_1);
    //     blockchain.receive_block(&block_1_2);
    //     blockchain.receive_block(&block_1_3);
    //     blockchain.receive_block(&block_1_4);
    //     blockchain.receive_block(&block_1_5);
    //     blockchain.receive_block(&block_1_6);
    //     blockchain.receive_block(&block_1_7);
    //     assert_eq!(blockchain.tip(), block_2_6.hash());

    //     //A3: insist on longest chain when there is no checkpoint appear
    //     let block_2_5_1 = generate_random_valid_block(&block_2_4.hash());
    //     let block_2_6_1 = generate_random_block_with_checkpoint(blockchain.test_get_latest_checkpoint(), block_2_5_1.hash());
    //     let block_2_7_1 = generate_random_valid_block(&block_2_6_1.hash());
    //     let block_2_8_1 = generate_random_valid_block(&block_2_7_1.hash());
    //     let block_2_9_1 = generate_random_valid_block(&block_2_8_1.hash());
    //     let block_2_10_1 = generate_random_valid_block(&block_2_9_1.hash());
    //     let block_2_11_1 = generate_random_valid_block(&block_2_10_1.hash());

    //     blockchain.receive_block(&block_2_5_1);
    //     blockchain.receive_block(&block_2_6_1);
    //     blockchain.receive_block(&block_2_7_1);
    //     blockchain.receive_block(&block_2_8_1);
    //     blockchain.receive_block(&block_2_9_1);
    //     blockchain.receive_block(&block_2_10_1);
    //     blockchain.receive_block(&block_2_11_1);
    //     assert_eq!(blockchain.tip(), block_2_11_1.hash());

    //     //A4: readjust tip when block with real checkpoint comes up
    //     let block_2_7_2 = generate_random_valid_block(&block_2_6.hash());
    //     let block_2_8_2 = generate_random_valid_block(&block_2_7_2.hash());
    //     let block_2_9_2 = generate_random_valid_block(&block_2_8_2.hash());
    //     let mut c2 = Checkpoint::new(block_2_8_2.hash(), rng.gen::<u32>(), 1);
    //     c2.set_sig(c2.generate_signature().unwrap());
    //     let block_2_10_2 = generate_random_block_with_checkpoint(c2.clone(), block_2_9_2.hash());
    //     blockchain.receive_block(&block_2_7_2);
    //     blockchain.receive_block(&block_2_8_2);
    //     blockchain.receive_block(&block_2_9_2);
    //     blockchain.receive_block(&block_2_10_2);
    //     assert_eq!(blockchain.test_get_latest_checkpoint(), c2);
    //     assert_eq!(blockchain.tip(), block_2_10_2.hash());
    // }

    // #[test]
    // fn simple_orphan_buffer_test() {
    //     let mut rng = rand::thread_rng();
    //     let mut difficulty_bytes = [0; 32];
    //     for i in 0..32{
    //         difficulty_bytes[i] = 255;
    //     }
    //     let mut blockchain = Blockchain::new_with_difficulty(4, 1, 2, 0, 0, difficulty_bytes.into());
    //     let genesis_checkpoint = blockchain.test_get_latest_checkpoint();
    //     let genesis_hash = blockchain.tip();
    //     let block_2_1 = generate_random_valid_block(&genesis_hash);
    //     let block_2_2 = generate_random_block_with_checkpoint(blockchain.test_get_latest_checkpoint(), block_2_1.hash());
    //     let block_2_3 = generate_random_valid_block(&block_2_2.hash());
    //     let block_2_4 = generate_random_valid_block(&block_2_3.hash());
    //     let block_2_5 = generate_random_valid_block(&block_2_4.hash());
    //     let mut c1 = Checkpoint::new(block_2_4.hash(), rng.gen::<u32>(), 1);
    //     c1.set_sig(c1.generate_signature().unwrap());
    //     let block_2_6 = generate_random_block_with_checkpoint(c1, block_2_5.hash());
    //     blockchain.receive_block(&block_2_1);
    //     blockchain.receive_block(&block_2_3);
    //     blockchain.receive_block(&block_2_4);
    //     blockchain.receive_block(&block_2_5);
    //     blockchain.receive_block(&block_2_6);
    //     blockchain.receive_block(&block_2_2);
    //     assert_eq!(blockchain.tip(), block_2_6.hash());
    // }

    // #[test]
    // fn slightly_complex_orphan_buffer_test() {
    //     let mut rng = rand::thread_rng();
    //     let mut difficulty_bytes = [0; 32];
    //     for i in 0..32{
    //         difficulty_bytes[i] = 255;
    //     }
    //     let mut blockchain = Blockchain::new_with_difficulty(4, 1, 2, 0, 0, difficulty_bytes.into());
    //     let genesis_checkpoint = blockchain.test_get_latest_checkpoint();
    //     let genesis_hash = blockchain.tip();
    //     let block_2_1 = generate_random_valid_block(&genesis_hash);
    //     let block_2_2 = generate_random_block_with_checkpoint(blockchain.test_get_latest_checkpoint(), block_2_1.hash());
    //     let block_2_3 = generate_random_valid_block(&block_2_2.hash());
    //     let block_2_4 = generate_random_valid_block(&block_2_3.hash());
    //     let block_2_5 = generate_random_valid_block(&block_2_4.hash());
    //     let mut c1 = Checkpoint::new(block_2_4.hash(), rng.gen::<u32>(), 1);
    //     c1.set_sig(c1.generate_signature().unwrap());
    //     let block_2_6 = generate_random_block_with_checkpoint(c1, block_2_5.hash());
    //     blockchain.receive_block(&block_2_1);
    //     blockchain.receive_block(&block_2_3);
    //     blockchain.receive_block(&block_2_4);
    //     blockchain.receive_block(&block_2_5);
    //     blockchain.receive_block(&block_2_6);
    //     blockchain.receive_block(&block_2_2);
    //     assert_eq!(blockchain.tip(), block_2_6.hash());
    // }

    // #[test]
    // fn harder_orphan_buffer_test() {
    //     let mut rng = rand::thread_rng();
    //     let mut difficulty_bytes = [0; 32];
    //     for i in 0..32{
    //         difficulty_bytes[i] = 255;
    //     }
    //     let mut blockchain = Blockchain::new_with_difficulty(4, 1, 2, 0, 0, difficulty_bytes.into());
    //     let genesis_checkpoint = blockchain.test_get_latest_checkpoint();
    //     let genesis_hash = blockchain.tip();

    //     let block_1_1 = generate_random_valid_block(&genesis_hash);
    //     let block_1_2 = generate_random_block_with_checkpoint(genesis_checkpoint, block_1_1.hash());
    //     let block_1_3 = generate_random_valid_block(&block_1_2.hash());
    //     let block_1_4 = generate_random_valid_block(&block_1_3.hash());
    //     let block_1_5 = generate_random_valid_block(&block_1_4.hash());
    //     let block_1_6 = generate_random_valid_block(&block_1_5.hash());
    //     let block_1_7 = generate_random_valid_block(&block_1_6.hash());

    //     blockchain.receive_block(&block_1_1);
    //     blockchain.receive_block(&block_1_2);
    //     blockchain.receive_block(&block_1_3);
    //     blockchain.receive_block(&block_1_4);
    //     blockchain.receive_block(&block_1_5);
    //     blockchain.receive_block(&block_1_6);
    //     blockchain.receive_block(&block_1_7);
    //     assert_eq!(blockchain.tip(), block_1_7.hash());

    //     let block_2_1 = generate_random_valid_block(&genesis_hash);
    //     let block_2_2 = generate_random_block_with_checkpoint(blockchain.test_get_latest_checkpoint(), block_2_1.hash());
    //     let block_2_3 = generate_random_valid_block(&block_2_2.hash());
    //     let block_2_4 = generate_random_valid_block(&block_2_3.hash());
    //     let block_2_5 = generate_random_valid_block(&block_2_4.hash());
    //     let mut c1 = Checkpoint::new(block_2_4.hash(), rng.gen::<u32>(), 1);
    //     c1.set_sig(c1.generate_signature().unwrap());
    //     // let block_2_6 = generate_random_block_with_checkpoint(c1.clone(), block_2_5.hash());

    //     blockchain.receive_block(&block_2_1);
    //     blockchain.receive_block(&block_2_2);
    //     blockchain.receive_block(&block_2_4);
    //     blockchain.receive_block(&block_2_5);
    //     blockchain.receive_checkpoint(&c1);
    //     blockchain.receive_block(&block_2_3);
    //     assert_eq!(blockchain.tip(), block_2_5.hash());
    //     assert_eq!(blockchain.test_get_latest_checkpoint(), c1);

    // }



    // #[test]
    // fn midtermproject1_insert_one() {
    //     let mut blockchain = Blockchain::new(10, 0, 1, 0);
    //     let genesis_hash = blockchain.tip();
    //     let mut block = generate_random_block(&genesis_hash);
    //     blockchain.insert(&block);
    //     assert_eq!(blockchain.tip(), block.hash());
    // }
    // #[test]
    // fn midtermproject1_insert_3_2() {
    //     let mut difficulty_bytes = [0; 32];
    //     for i in 0..32{
    //         difficulty_bytes[i] = 255;
    //     }
    //     let mut blockchain = Blockchain::new_with_difficulty(10, 0, 3, 0,difficulty_bytes.into());
    //     let genesis_hash = blockchain.tip();
        
    //     let block_1 = generate_random_valid_block(&genesis_hash);
    //     blockchain.insert(&block_1);
    //     assert_eq!(blockchain.tip(), block_1.hash());
    //     let block_2 = generate_random_valid_block(&block_1.hash());
    //     blockchain.insert(&block_2);
    //     assert_eq!(blockchain.tip(), block_2.hash());
    //     let block_3 = generate_random_valid_block(&block_2.hash());
    //     blockchain.insert(&block_3);
    //     assert_eq!(blockchain.tip(), block_3.hash());
    //     let fork_block_1 = generate_random_block(&genesis_hash);
    //     blockchain.insert(&fork_block_1);
    //     assert_eq!(blockchain.tip(), block_3.hash());
    //     let fork_block_2 = generate_random_block(&fork_block_1.hash());
    //     blockchain.insert(&fork_block_2);
    //     assert_eq!(blockchain.tip(), block_3.hash());
    // }
    // #[test]
    // fn midtermproject1_insert_2_3() {
    //     let mut blockchain = Blockchain::new(10, 0, 1, 0);
    //     let genesis_hash = blockchain.tip();
    //     let block_1 = generate_random_block(&genesis_hash);
    //     blockchain.insert(&block_1);
    //     assert_eq!(blockchain.tip(), block_1.hash());
    //     let block_2 = generate_random_block(&block_1.hash());
    //     blockchain.insert(&block_2);
    //     assert_eq!(blockchain.tip(), block_2.hash());
    //     let fork_block_1 = generate_random_block(&genesis_hash);
    //     blockchain.insert(&fork_block_1);
    //     assert_eq!(blockchain.tip(), block_2.hash());
    //     let fork_block_2 = generate_random_block(&fork_block_1.hash());
    //     blockchain.insert(&fork_block_2);
    //     //assert_eq!(blockchain.tip(), block_2.hash());
    //     let fork_block_3 = generate_random_block(&fork_block_2.hash());
    //     blockchain.insert(&fork_block_3);
    //     assert_eq!(blockchain.tip(), fork_block_3.hash());
    // }
    // #[test]
    // fn midtermproject1_insert_3_fork_and_back() {
    //     let mut blockchain = Blockchain::new(10, 0, 1, 0);
    //     let genesis_hash = blockchain.tip();
    //     let block_1 = generate_random_block(&genesis_hash);
    //     blockchain.insert(&block_1);
    //     assert_eq!(blockchain.tip(), block_1.hash());
    //     let block_2 = generate_random_block(&block_1.hash());
    //     blockchain.insert(&block_2);
    //     assert_eq!(blockchain.tip(), block_2.hash());
    //     let block_3 = generate_random_block(&block_2.hash());
    //     blockchain.insert(&block_3);
    //     assert_eq!(blockchain.tip(), block_3.hash());
    //     let fork_block_1 = generate_random_block(&block_2.hash());
    //     blockchain.insert(&fork_block_1);
    //     let fork_block_2 = generate_random_block(&fork_block_1.hash());
    //     blockchain.insert(&fork_block_2);
    //     assert_eq!(blockchain.tip(), fork_block_2.hash());
    //     let block_4 = generate_random_block(&block_3.hash());
    //     blockchain.insert(&block_4);
    //     let block_5 = generate_random_block(&block_4.hash());
    //     blockchain.insert(&block_5);
    //     assert_eq!(blockchain.tip(), block_5.hash());
    // }
    // #[test]
    // fn midtermproject1_insert_3_fork_and_6() {
    //     let mut blockchain = Blockchain::new(10, 0, 1, 0);
    //     let genesis_hash = blockchain.tip();
    //     let block_1 = generate_random_block(&genesis_hash);
    //     blockchain.insert(&block_1);
    //     assert_eq!(blockchain.tip(), block_1.hash());
    //     let block_2 = generate_random_block(&block_1.hash());
    //     blockchain.insert(&block_2);
    //     assert_eq!(blockchain.tip(), block_2.hash());
    //     let block_3 = generate_random_block(&block_2.hash());
    //     blockchain.insert(&block_3);
    //     assert_eq!(blockchain.tip(), block_3.hash());
    //     let fork_block_1 = generate_random_block(&block_2.hash());
    //     blockchain.insert(&fork_block_1);
    //     let fork_block_2 = generate_random_block(&fork_block_1.hash());
    //     blockchain.insert(&fork_block_2);
    //     assert_eq!(blockchain.tip(), fork_block_2.hash());
    //     let another_block_1 = generate_random_block(&genesis_hash);
    //     blockchain.insert(&another_block_1);
    //     assert_eq!(blockchain.tip(), fork_block_2.hash());
    //     let another_block_2 = generate_random_block(&another_block_1.hash());
    //     blockchain.insert(&another_block_2);
    //     assert_eq!(blockchain.tip(), fork_block_2.hash());
    //     let another_block_3 = generate_random_block(&another_block_2.hash());
    //     blockchain.insert(&another_block_3);
    //     assert_eq!(blockchain.tip(), fork_block_2.hash());
    //     let another_block_4 = generate_random_block(&another_block_3.hash());
    //     blockchain.insert(&another_block_4);
    //     let another_block_5 = generate_random_block(&another_block_4.hash());
    //     blockchain.insert(&another_block_5);
    //     assert_eq!(blockchain.tip(), another_block_5.hash());
    //     let another_block_6 = generate_random_block(&another_block_5.hash());
    //     blockchain.insert(&another_block_6);
    //     assert_eq!(blockchain.tip(), another_block_6.hash());
    // }

    // #[test]
    // fn normal_checkpoint_flow() {
    //     let mut difficulty_bytes = [0; 32];
    //     for i in 0..32{
    //         difficulty_bytes[i] = 255;
    //     }
    //     let mut blockchain = Blockchain::new_with_difficulty(2, 0, 1, 0, difficulty_bytes.into());
    //     let genesis = blockchain.tip();

    // }

//     #[test]
//     fn checkpoint_switch_test() {
//         let mut difficulty_bytes = [0; 32];
//         for i in 0..32{
//             difficulty_bytes[i] = 255;
//         }
//         let mut blockchain = Blockchain::new_with_difficulty(5, 0, 3, 0, 0,difficulty_bytes.into());
//         let genesis_hash = blockchain.tip();
        
//         let block_1 = generate_random_valid_block(&genesis_hash);
//         let block_2 = generate_random_valid_block(&block_1.hash());
//         let block_3 = generate_random_valid_block(&block_2.hash());
//         let block_4 = generate_random_valid_block(&block_3.hash());        
//         let block_5 = generate_random_valid_block(&block_4.hash());        
//         let block_6_left = generate_random_valid_block(&block_5.hash());        
//         let block_7_left = generate_random_valid_block(&block_6_left.hash());   
//         let block_8_left = generate_random_valid_block(&block_7_left.hash());        
     
//         let block_6_right = generate_random_valid_block(&block_5.hash());

//         let checkpoint = Checkpoint::create_genesis_checkpoint(block_6_right.hash());
//         let block_7_right = generate_random_block_with_checkpoint(checkpoint.clone() , block_6_right.hash());
//         let block_7_right_2 = generate_random_block_with_checkpoint(checkpoint.clone() , block_6_right.hash());
//         let block_8_right = generate_random_valid_block(&block_7_right_2.hash());
//         blockchain.insert(&block_1);
//         blockchain.insert(&block_2);
//         blockchain.insert(&block_3);
//         blockchain.insert(&block_4);
//         blockchain.insert(&block_5);
//         blockchain.insert(&block_6_left);
//         blockchain.insert(&block_7_left);
//         blockchain.insert(&block_8_left);
//         blockchain.insert(&block_6_right);
//         // it should set check the latest checkpoint to block 5, and reset tip to block7 
//         blockchain.insert(&block_7_right);
//         assert_eq!(blockchain.latest_checkpoint.get_block() , block_6_right.hash());

//         assert_eq!(blockchain.tip(), block_7_right.hash());
//         blockchain.insert(&block_7_right_2);
//         // don't update tip yet since it's a tie
//         assert_eq!(blockchain.tip(), block_7_right.hash());
//         blockchain.insert(&block_8_right);
//         // it should be set to block_8_right because they share the same checkpoint, but block_8_right is longer.
//         assert_eq!(blockchain.tip(), block_8_right.hash());
//     }
// }
