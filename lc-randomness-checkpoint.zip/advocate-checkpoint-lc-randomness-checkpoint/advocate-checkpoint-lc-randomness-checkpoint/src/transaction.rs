use rand::random;
use bincode::serialize;
use untrusted::Input;
use serde::{Serialize,Deserialize};
use ring::signature::{Ed25519KeyPair, Signature, KeyPair, VerificationAlgorithm, EdDSAParameters, ED25519};
use ring::digest::{SHA256, digest};
use crate::crypto::hash::{H256, Hashable, H160};
use std::collections::HashMap;


#[derive(Serialize, Deserialize, Debug, Default, Clone)]
pub struct Txin {
    prev_tx_hash: [u8; 32],
    prev_tx_idx: [u8; 4],
    sequence_no: [u8; 4],
}

#[derive(Serialize, Deserialize, Debug, Default, Clone)]
pub struct Txout {
    value: [u8; 8],
    recipient: H160,
}

#[derive(Serialize, Deserialize, Debug, Default, Clone)]
pub struct Transaction{
    version: [u8; 4],
    // TODO: flag: accompany with witness
    in_counter: u8,
    inputs: Vec<Txin>,
    out_counter: u8,
    outputs: Vec<Txout>,
    // TODO: witnesses: could be implemented later on
    lock_time: [u8; 4],
    pub_key: Option<Vec<u8>>,
    sig: Option<Vec<u8>>,
}

#[derive(Serialize, Deserialize, Debug, Default, Clone)]
pub struct Mempool {
    pool: HashMap<H256, Transaction>,
}

impl Hashable for Transaction {
    fn hash(&self) -> H256 {
        digest(&SHA256, &serialize(&self).unwrap()).into()
    } 
}

impl Transaction {

    pub fn signTransaction(&self, key: &Ed25519KeyPair) -> Transaction {

        let mut the_tran = self.clone();
        let the_key = key.clone();
        let sig = sign(&the_tran, &the_key);

        let pub_key_in_array: &[u8]  = the_key.public_key().as_ref();
        let sig_in_array: &[u8] = sig.as_ref();

        the_tran.pub_key = Some(
            pub_key_in_array.to_vec()
        );

        the_tran.sig = Some(
            sig_in_array.to_vec()
        );

        the_tran
    }

    // TODO: check double spending attack
    pub fn doubleSpendChecks(&self) -> bool {
        true
    }


    pub fn verifyTransactionSig(&self) -> bool {
        
        if self.pub_key.is_none() || self.sig.is_none() {
            return false;
        }

        let mut the_tran = self.clone();
        let the_pub_key= the_tran.pub_key.unwrap().clone();
        let the_sig = the_tran.sig.unwrap().clone();
        the_tran.sig = None;
        the_tran.pub_key = None;
        
        if !verify(&the_tran, the_pub_key.as_ref(), the_sig.as_ref()) {
            return false;
        }

        // TODO: check input transactions' recepient
        // if self.inputs.len() as u8 != self.in_counter {
        //     return false;
        // }

        // let addr: H160 = digest(&SHA256, the_pub_key.as_ref()).into();

        // for input in self.inputs.iter() {

        //     if addr != input.recipient {
        //         return false;
        //     }
            
        // }

        true
    }
}


/// Create digital signature of a transaction
pub fn sign(t: &Transaction, key: &Ed25519KeyPair) -> Signature {
    key.sign(&serialize(t).unwrap())
}

/// Verify digital signature of a transaction, using public key instead of secret key
pub fn verify(t: &Transaction, public_key: &[u8], signature: &[u8]) -> bool {
    ED25519.verify(
        Input::from(public_key), 
        Input::from(&serialize(t).unwrap()),
        Input::from(signature),
    ).is_ok()
}

#[cfg(any(test, test_utilities))]
mod tests {
    use super::*;
    use crate::crypto::key_pair;

    pub fn generate_random_transaction() -> Transaction {
        Transaction {
            version: [0; 4],
            in_counter: 0,
            inputs: Vec::new(),
            out_counter: 0,
            outputs: Vec::new(),
            lock_time: [0; 4],
            pub_key: None,
            sig: None,
        }
    }
    #[test]
    fn sign_verify() {
        let t = generate_random_transaction();
        let key = key_pair::random();
        let signature = sign(&t, &key);
        assert!(verify(&t, key.public_key().as_ref(), signature.as_ref()));
    }
}
