#!/usr/bin/env bash

curl http://127.0.0.1:7000/miner/resumetransmission?lambda=4000
curl http://127.0.0.1:7001/miner/resumetransmission?lambda=6000
curl http://127.0.0.1:7002/miner/resumetransmission?lambda=6000

