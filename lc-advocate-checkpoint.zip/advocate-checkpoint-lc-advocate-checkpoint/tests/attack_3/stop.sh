#!/usr/bin/env bash

curl http://127.0.0.1:7000/miner/stop
curl http://127.0.0.1:7001/miner/stop
curl http://127.0.0.1:7002/miner/stop
