#!/usr/bin/env bash

curl http://127.0.0.1:7000/miner/start?lambda=0
curl http://127.0.0.1:7001/miner/start?lambda=0
curl http://127.0.0.1:7002/miner/start?lambda=0