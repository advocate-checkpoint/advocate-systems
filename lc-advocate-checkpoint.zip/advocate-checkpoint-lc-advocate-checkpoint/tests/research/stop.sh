#!/usr/bin/env bash

curl http://127.0.0.1:7000/miner/stop
curl http://127.0.0.1:7001/miner/stop
curl http://127.0.0.1:7002/miner/stop

curl http://127.0.0.1:7002/miner/block/metrics | jq '.' > honest_block_metrics.json
curl http://127.0.0.1:7002/miner/checkpoint/metrics | jq '.' > checkpoint_metrics.json
curl http://127.0.0.1:7001/miner/block/metrics | jq '.' > adv_block_metrics.json
