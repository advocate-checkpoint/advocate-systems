#[cfg(test)]
#[macro_use]
extern crate hex_literal;

pub mod api;
pub mod block;
pub mod checkpoint;
pub mod blockchain;
pub mod crypto;
pub mod miner;
pub mod network;
pub mod transaction;

use clap::clap_app;
use crossbeam::channel;
use log::{error, info};
use api::Server as ApiServer;
use network::{server, worker};
use std::net;
use std::process;
use std::thread;
use std::time;
use std::sync::{ Arc, Mutex };

use mysql::*;
use mysql::prelude::*;
// use influxdb::Client;

fn main() {
    // parse command line arguments
    let matches = clap_app!(Bitcoin =>
     (version: "0.1")
     (about: "Bitcoin client")
     (@arg verbose: -v ... "Increases the verbosity of logging")
     (@arg peer_addr: --p2p [ADDR] default_value("127.0.0.1:6000") "Sets the IP address and the port of the P2P server")
     (@arg api_addr: --api [ADDR] default_value("127.0.0.1:7000") "Sets the IP address and the port of the API server")
     (@arg known_peer: -c --connect ... [PEER] "Sets the peers to connect to at start")
     (@arg p2p_workers: --("p2p-workers") [INT] default_value("4") "Sets the number of worker threads for P2P server")
     (@arg checkpoint_node: --checkpoint_node [INT] default_value("0") "Sets the checkpoint property of the node")
     (@arg adv: --adversary [INT] default_value("0") "Sets the node to be adversary")
     (@arg checkpoint_epoch: --checkpoint_epoch [INT] default_value("10") "Sets the checkpoint epoch in the chain")
     (@arg checkpoint_k1: --checkpoint_k1 [INT] default_value("0") "Sets the checkpoint K1 in the chain")
     (@arg checkpoint_k2: --checkpoint_k2 [INT] default_value("1") "Sets the checkpoint K2 in the chain")
     (@arg cp_delay: --cp_delay [INT] default_value("0") "Sets the network delay for checkpoint in the chain")
     (@arg net_delay: --net_delay [INT] default_value("0") "Sets the network delay in the chain")
     (@arg live_demo: --live_demo [INT] default_value("0") "Sets the live demo switch")
     (@arg live_demo_timescale: --live_demo_timescale [INT] default_value("100") "Sets the live demo db logging speed")
    )
    .get_matches();

    // init checkpoint parameters
    let checkpoint_node = matches
        .value_of("checkpoint_node")
        .unwrap()
        .parse::<usize>()
        .unwrap_or_else(|e| {
            error!("Error parsing checkpoint node: {}", e);
            process::exit(1);
        });
    let checkpoint_epoch = matches
        .value_of("checkpoint_epoch")
        .unwrap()
        .parse::<usize>()
        .unwrap_or_else(|e| {
            error!("Error parsing checkpoint epoch: {}", e);
            process::exit(1);
        });
    let checkpoint_k1 = matches
        .value_of("checkpoint_k1")
        .unwrap()
        .parse::<usize>()
        .unwrap_or_else(|e| {
            error!("Error parsing checkpoint k1: {}", e);
            process::exit(1);
        });
    let checkpoint_k2 = matches
        .value_of("checkpoint_k2")
        .unwrap()
        .parse::<usize>()
        .unwrap_or_else(|e| {
            error!("Error parsing checkpoint k2: {}", e);
            process::exit(1);
        });

    // init live_demo parameter 
    let live_demo = matches
    .value_of("live_demo")
    .unwrap()
    .parse::<usize>()
    .unwrap_or_else(|e| {
        error!("Error parsing live demo: {}", e);
        process::exit(1);
    });

    let live_demo_timescale = matches
    .value_of("live_demo_timescale")
    .unwrap()
    .parse::<usize>()
    .unwrap_or_else(|e| {
        error!("Error parsing live demo timescale: {}", e);
        process::exit(1);
    });

    // init cp delay
    let cp_delay = matches
    .value_of("cp_delay")
    .unwrap()
    .parse::<usize>()
    .unwrap_or_else(|e| {
        error!("Error parsing cp delay: {}", e);
        process::exit(1);
    });

    // init network delay
    let network_delay = matches
    .value_of("net_delay")
    .unwrap()
    .parse::<usize>()
    .unwrap_or_else(|e| {
        error!("Error parsing network delay: {}", e);
        process::exit(1);
    });

    // init adversary node
    let adv = matches
    .value_of("adv")
    .unwrap()
    .parse::<usize>()
    .unwrap_or_else(|e| {
        error!("Error parsing adversary flag: {}", e);
        process::exit(1);
    });

    // init logger
    let verbosity = matches.occurrences_of("verbose") as usize;
    stderrlog::new().verbosity(verbosity).init().unwrap();

    // parse p2p server address
    let p2p_addr = matches
        .value_of("peer_addr")
        .unwrap()
        .parse::<net::SocketAddr>()
        .unwrap_or_else(|e| {
            error!("Error parsing P2P server address: {}", e);
            process::exit(1);
        });

    // parse api server address
    let api_addr = matches
        .value_of("api_addr")
        .unwrap()
        .parse::<net::SocketAddr>()
        .unwrap_or_else(|e| {
            error!("Error parsing API server address: {}", e);
            process::exit(1);
        });

    // create channels between server and worker
    let (msg_tx, msg_rx) = channel::unbounded();
    
    // create the blockchain that we will mine on
    let the_chain = Arc::new(Mutex::new(
        blockchain::Blockchain::new(
            checkpoint_epoch as u64, 
            checkpoint_k1 as u64, 
            checkpoint_k2 as u64, 
            checkpoint_node as u64,
            adv as u64,
            cp_delay as u64,
    )));

    // start the p2p server
    let (server_ctx, server) = server::new(p2p_addr, msg_tx, network_delay as u64).unwrap();
    server_ctx.start().unwrap();

    // start the worker
    let p2p_workers = matches
        .value_of("p2p_workers")
        .unwrap()
        .parse::<usize>()
        .unwrap_or_else(|e| {
            error!("Error parsing P2P workers: {}", e);
            process::exit(1);
        });
    let worker_ctx = worker::new(
        p2p_workers,
        msg_rx,
        &server,
        &the_chain,
    );
    worker_ctx.start();

    // initialize mysqldb connection
    // let mySQLurl = "mysql://root:qwa147852369@localhost:3306/prismdemo";
    // let pool = Pool::new(mySQLurl);
    // if pool.is_err() {
    //     error!("Error connecting db: {}", pool.err().unwrap());
    //     process::exit(1);
    // }
    

    // initialize influxdb connection
    // let influxdb_url = "http://localhost:8086";
    // let client = Client::new(influxdb_url, "live-demo1").with_auth("root", "qwa147852369");

    // start the miner
    let (miner_ctx, miner) = miner::new(
        &server,
        &the_chain,
        // &client,
        // &pool.unwrap(),
        checkpoint_node as u64,
        live_demo as u64,
        live_demo_timescale as u64,
        adv as u64,
    );
    miner_ctx.start();

    // connect to known peers
    if let Some(known_peers) = matches.values_of("known_peer") {
        let known_peers: Vec<String> = known_peers.map(|x| x.to_owned()).collect();
        let server = server.clone();
        thread::spawn(move || {
            for peer in known_peers {
                loop {
                    let addr = match peer.parse::<net::SocketAddr>() {
                        Ok(x) => x,
                        Err(e) => {
                            error!("Error parsing peer address {}: {}", &peer, e);
                            break;
                        }
                    };
                    match server.connect(addr) {
                        Ok(_) => {
                            info!("Connected to outgoing peer {}", &addr);
                            break;
                        }
                        Err(e) => {
                            error!(
                                "Error connecting to peer {}, retrying in one second: {}",
                                addr, e
                            );
                            thread::sleep(time::Duration::from_millis(1000));
                            continue;
                        }
                    }
                }
            }
        });
    }


    // start the API server
    ApiServer::start(
        api_addr,
        &miner,
        &server,
        &the_chain,
    );

    loop {
        std::thread::park();
    }
}
