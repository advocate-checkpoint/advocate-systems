extern crate rand;

use crate::blockchain::{Blockchain, BlockResult};
use crate::block::Block;
use crate::crypto::hash::{ Hashable, H256 };
use crate::network::message::Message;
use crate::network::server::Handle as ServerHandle;
use chrono::prelude::*;
use crossbeam::channel::{unbounded, Receiver, Sender, TryRecvError};
use hex;
use log::{info, error};
use mysql::*;
use mysql::prelude::*;
use rand::distributions::{Exp, Distribution};
use rand::Rng;
use std::thread;
use std::time;
use std::ops::Deref;
use std::sync::{ Arc, Mutex };



enum ControlSignal {
    Start(u64), // the number controls the lambda of interval between block generation
    Exit,
    StopTransmission(u64),
    ResumeTransmission(u64),
    StopCPGeneration,
    ResumeCPGeneration,
}

enum OperatingState {
    Paused,
    Run(u64),
    ShutDown,
    StopTransmission(u64),
}

pub struct Context {
    /// Channel for receiving control signal
    control_chan: Receiver<ControlSignal>,
    operating_state: OperatingState,
    server: ServerHandle,
    chain: Arc<Mutex<Blockchain>>,
    timestamp: Arc<Mutex<u64>>,
    // dbpool: Pool,
    checkpoint_node: u64,
    live_demo: u64,
    live_demo_timescale: u64,
    adv: u64, 
}

#[derive(Clone)]
pub struct Handle {
    /// Channel for sending signal to the miner thread
    control_chan: Sender<ControlSignal>,
}

pub fn new(
    server: &ServerHandle,
    blockchain: &Arc<Mutex<Blockchain>>,
    // dbpool: &Pool,
    checkpoint_node: u64,
    live_demo: u64,
    live_demo_timescale: u64,
    adv: u64,
) -> (Context, Handle) {
    let (signal_chan_sender, signal_chan_receiver) = unbounded();
    let timestamp = time::SystemTime::now().duration_since(time::UNIX_EPOCH).unwrap().as_millis() as u64;

    let ctx = Context {
        control_chan: signal_chan_receiver,
        operating_state: OperatingState::Paused,
        server: server.clone(),
        chain: Arc::clone(blockchain),
        timestamp: Arc::new(Mutex::new(timestamp)),
        // dbpool: dbpool.clone(),
        checkpoint_node: checkpoint_node,
        live_demo: live_demo,
        live_demo_timescale: live_demo_timescale,
        adv: adv,
    };

    let handle = Handle {
        control_chan: signal_chan_sender,
    };

    (ctx, handle)
}

impl Handle {
    pub fn exit(&self) {
        self.control_chan.send(ControlSignal::Exit).unwrap();
    }

    pub fn start(&self, lambda: u64) {
        self.control_chan
            .send(ControlSignal::Start(lambda))
            .unwrap();
    }

    pub fn stop(&self) {
        self.control_chan
            .send(ControlSignal::Exit)
            .unwrap();
    }

    pub fn stopTransmission(&self, lambda: u64) {
        self.control_chan
            .send(ControlSignal::StopTransmission(lambda))
            .unwrap();
    }

    pub fn resumeTransmission(&self, lambda: u64) {
        self.control_chan
            .send(ControlSignal::ResumeTransmission(lambda))
            .unwrap();
    }

    pub fn stopCPGeneration(&self) {
        self.control_chan
            .send(ControlSignal::StopCPGeneration)
            .unwrap();
    }

    pub fn resumeCPGeneration(&self) {
        self.control_chan
            .send(ControlSignal::ResumeCPGeneration)
            .unwrap();
    }

}

impl Context {
    pub fn start(mut self) {
        thread::Builder::new()
            .name("miner".to_string())
            .spawn(move || {
                self.miner_loop()
            })
            .unwrap();
        info!("Miner initialized into paused mode");
    }

    fn handle_control_signal(&mut self, signal: ControlSignal) {
        match signal {
            ControlSignal::Exit => {
                info!("Miner shutting down");
                self.operating_state = OperatingState::ShutDown;
            }
            ControlSignal::Start(i) => {
                info!("Miner starting in continuous mode with lambda {}", i);
                self.operating_state = OperatingState::Run(i);
            }
            ControlSignal::StopTransmission(i) => {
                info!("Miner stopping transmitting blocks");
                self.operating_state = OperatingState::StopTransmission(i)
            }
            ControlSignal::ResumeTransmission(i) => {
                info!("Miner resuming transmitting blocks");
                self.operating_state = OperatingState::Run(i);
            }
            ControlSignal::StopCPGeneration => {
                info!("Miner stopping generating CP certificates");
                let mut the_chain = self.chain.lock().unwrap();
                the_chain.set_pause_cp_generation(true);
            }
            ControlSignal::ResumeCPGeneration => {
                info!("Miner resuming generating CP certificates");
                let mut the_chain = self.chain.lock().unwrap();
                the_chain.set_pause_cp_generation(false);
            }
        }
    }

    fn miner_loop(&mut self) {
        let mut self_mined = 0;
        let mut pause_transmission = 0;
        // main mining loop
        loop {
            // check and react to control signals
            match self.operating_state {
                OperatingState::Paused => {
                    let signal = self.control_chan.recv().unwrap();
                    self.handle_control_signal(signal);
                    continue;
                }
                OperatingState::ShutDown => {
                    return;
                }
                _ => match self.control_chan.try_recv() {
                    Ok(signal) => {
                        self.handle_control_signal(signal);
                    }
                    Err(TryRecvError::Empty) => {}
                    Err(TryRecvError::Disconnected) => panic!("Miner control channel detached"),
                },
            }
            if let OperatingState::StopTransmission(_) = self.operating_state {
                pause_transmission = 1;
            } else {
                pause_transmission = 0;
            }

            if let OperatingState::ShutDown = self.operating_state {
                let the_chain = self.chain.lock().unwrap();
                info!("There are {} blocks in the longest chain", the_chain.get_chain_length());
                info!("There are {} blocks in the blockchain in total", the_chain.chain_size());
                info!("There are {} blocks that are self mined", self_mined);
                info!("There are {} blocks left in orphan buffer", the_chain.orphan_size());
                let latest_cp = the_chain.test_get_latest_checkpoint();
                info!("The latest checkpoint is: {}", hex::encode(latest_cp.hash()));
                // the_chain.test_print_orphan_information();
                // the_chain.test_print_block_in_chain();
                // info!("Average block relay is {}", the_chain.get_avg_block_relay());
                // info!("Entire blocks size is {}", the_chain.blocks_size_bytes());
                return;
            }
            let mut rng = rand::thread_rng();

            if let OperatingState::Run(i) = self.operating_state {
                if i != 0 {
                    let exp_dist = Exp::new(1.0/i as f64);
                    let rest = exp_dist.sample(&mut rng) - 1000.0;
                    info!("Looping time: {}", rest);
                    let interval = time::Duration::from_micros(rest as u64);
                    thread::sleep(interval);
                }
            }
            if let OperatingState::StopTransmission(i) = self.operating_state {
                if i != 0 {
                    let exp_dist = Exp::new(1.0/i as f64);
                    let rest = exp_dist.sample(&mut rng) - 1000.0;
                    info!("Looping time: {}", rest);
                    let interval = time::Duration::from_micros(rest as u64);
                    thread::sleep(interval);
                }
            }
            
            let the_chain = self.chain.lock().unwrap();
            let parent = the_chain.tip();
            let nonce = rng.gen::<u32>();
            let difficulty = the_chain.get_difficulty(&parent);
            // let curr_timestamp = time::SystemTime::now().duration_since(time::UNIX_EPOCH).unwrap().as_millis() as u64;

            // generate the block
            let mut test_block = Block::new(&parent, nonce, &difficulty);
            if the_chain.check_k1_k2_distance() {
                the_chain.set_latest_checkpoint(&mut test_block);
            }
            drop(the_chain);
            if test_block.hash() <= difficulty {
                let mut the_chain = self.chain.lock().unwrap();
                info!("construct: {}", test_block.hash());
                if self.adv != 0{
                    the_chain.update_adv_metrics(test_block.hash());
                }
                let result = the_chain.receive_block(&test_block);
                drop(the_chain);
                match result.message_type {
                    BlockResult::DropBlock => {},
                    BlockResult::ReceivedBlocks => {
                        if result.blockhashes.is_some() {
                            let blockhashes = result.blockhashes.unwrap();
                            if !blockhashes.is_empty() {
                                if pause_transmission == 0 {
                                    self.server.broadcast(Message::NewBlockHashes(blockhashes));
                                }
                            }
                        }
                        // self.server.broadcast(Message::NewBlockHashes(vec![test_block.hash()]));
                        if result.checkpoints.is_some() {
                            self.server.broadcast(Message::NewCheckpoints(result.checkpoints.unwrap().clone()));
                        }
                        self_mined += 1;
                    },
                    BlockResult::GetBlock => {}
                }
            }

            // if self.checkpoint_node != 0 && self.live_demo != 0 {
            //     let mut prev_timestamp = self.timestamp.lock().unwrap();
            //     if curr_timestamp - *prev_timestamp >= self.live_demo_timescale {
            //         *prev_timestamp = curr_timestamp;
            //         let (cp, cp_tip, tip) = the_chain.test_get_live_test_1();
            //         // let live_demo_data = livedemo1 {
            //         //     time: Utc::now(),
            //         //     checkpoint_height: cp,
            //         //     checkpoint_tip_height: cp_tip,
            //         //     tip_height: tip,
            //         // };
            //         // let exec_res = self.dbclient.query(
            //         //     &live_demo_data.into_query("demo1")
            //         // ).await;

            //         // if exec_res.is_err() {
            //         //     error!(
            //         //         "Error updaing demo db: {}", exec_res.err().unwrap()
            //         //     );
            //         // }
            //         let conn_wrapper = self.dbpool.get_conn();
            //         if conn_wrapper.is_err() {
            //             error!(
            //                 "Error getting db connection: {}", conn_wrapper.err().unwrap()
            //             );
            //         } else {
            //             let mut conn = conn_wrapper.unwrap();
            //             let fraction = 0.67+0.33 * (((curr_timestamp as i64 / 1000) as f64)/40.0).sin();
            //             let exec_res = conn.exec_iter(
            //                 "
            //                     INSERT INTO demo1 (checkpoint_height, checkpoint_tip_height, tip_height, fraction, time)
            //                     VALUES(:checkpoint_height, :checkpoint_tip_height, :tip_height, :fraction, :time)
            //                 ",
            //                 params! {
            //                     "checkpoint_height" => cp,
            //                     "checkpoint_tip_height" => cp_tip,
            //                     "tip_height" => tip,
            //                     "fraction" => fraction, 
            //                     "time" => NaiveDateTime::from_timestamp(Utc::now().timestamp(), 0),
            //                 }
            //             );
            //             if exec_res.is_err() {
            //                 error!(
            //                     "Error updaing demo db: {}", exec_res.err().unwrap()
            //                 );
            //             }
            //         }
            //     }
            //     drop(prev_timestamp);
            // }
        }
    }
}

/// Get the current UNIX timestamp
fn get_time() -> u128 {
    let cur_time = time::SystemTime::now().duration_since(time::SystemTime::UNIX_EPOCH);
    match cur_time {
        Ok(v) => {
            return v.as_millis();
        }
        Err(e) => println!("Error parsing time: {:?}", e),
    }
    // TODO: there should be a better way of handling this, or just unwrap and panic
    0
}
