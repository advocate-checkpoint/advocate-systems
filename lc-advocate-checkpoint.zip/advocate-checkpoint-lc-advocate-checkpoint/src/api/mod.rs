use serde::Serialize;
use crate::miner::Handle as MinerHandle;
use crate::network::server::Handle as NetworkServerHandle;
use crate::network::message::Message;
use crate::blockchain::Blockchain;

use log::{info, error};
use std::collections::HashMap;
use std::thread;
use tiny_http::Header;
use tiny_http::Response;
use tiny_http::Server as HTTPServer;
use url::Url;

use std::fs::File;
use std::io::Read;
use std::time;
use std::net;
use serde_json;
use std::sync::{ Arc, Mutex };



pub struct Server {
    handle: HTTPServer,
    miner: MinerHandle,
    network: NetworkServerHandle,
    blockchain: Arc<Mutex<Blockchain>>,
}

#[derive(Serialize)]
struct ApiResponse {
    success: bool,
    message: String,
}

macro_rules! respond_result {
    ( $req:expr, $success:expr, $message:expr ) => {{
        let content_type = "Content-Type: application/json".parse::<Header>().unwrap();
        let payload = ApiResponse {
            success: $success,
            message: $message.to_string(),
        };
        let resp = Response::from_string(serde_json::to_string_pretty(&payload).unwrap())
            .with_header(content_type);
        $req.respond(resp).unwrap();
    }};
}


macro_rules! respond_json {
    ( $req:expr, $message:expr ) => {{
        let content_type = "Content-Type: application/json".parse::<Header>().unwrap();
        let resp = Response::from_string(serde_json::to_string_pretty(&$message).unwrap())
            .with_header(content_type);
        $req.respond(resp).unwrap();
    }};
}

impl Server {
    pub fn start(
        addr: std::net::SocketAddr,
        miner: &MinerHandle,
        network: &NetworkServerHandle,
        blockchain: &Arc<Mutex<Blockchain>>,
    ) {
        let handle = HTTPServer::http(&addr).unwrap();
        let server = Self {
            handle,
            miner: miner.clone(),
            network: network.clone(),
            blockchain: Arc::clone(blockchain),
        };
        thread::spawn(move || {
            for req in server.handle.incoming_requests() {
                let miner = server.miner.clone();
                let network = server.network.clone();
                let blockchain = Arc::clone(&server.blockchain);
                thread::spawn(move || {
                    // a valid url requires a base
                    let base_url = Url::parse(&format!("http://{}/", &addr)).unwrap();
                    let url = match base_url.join(req.url()) {
                        Ok(u) => u,
                        Err(e) => {
                            respond_result!(req, false, format!("error parsing url: {}", e));
                            return;
                        }
                    };
                    match url.path() {
                        "/miner/start" => {
                            let params = url.query_pairs();
                            let params: HashMap<_, _> = params.into_owned().collect();
                            let lambda = match params.get("lambda") {
                                Some(v) => v,
                                None => {
                                    respond_result!(req, false, "missing lambda");
                                    return;
                                }
                            };
                            let lambda = match lambda.parse::<u64>() {
                                Ok(v) => v,
                                Err(e) => {
                                    respond_result!(
                                        req,
                                        false,
                                        format!("error parsing lambda: {}", e)
                                    );
                                    return;
                                }
                            };
                            miner.start(lambda);
                            respond_result!(req, true, "ok");
                        }
                        "/miner/stop" => {
                            miner.stop();
                            respond_result!(req, true, "ok");
                        }
                        "/miner/block/metrics" => {
                            let blockchain = blockchain.lock().unwrap();
                            let block_info = blockchain.test_get_block_metrics();
                            drop(blockchain);
                            if block_info.is_left() {
                                respond_json!(req, block_info.left().unwrap());
                            } else {
                                respond_json!(req, block_info.right().unwrap());
                            }
                        }
                        "/miner/checkpoint/metrics" => {
                            let blockchain = blockchain.lock().unwrap();
                            let checkpoint_metrics = blockchain.test_get_checkpoint_metrics();
                            drop(blockchain);
                            respond_json!(req, checkpoint_metrics);
                        }
                        "/miner/pausetransmission" => {
                            let params = url.query_pairs();
                            let params: HashMap<_, _> = params.into_owned().collect();
                            let lambda = match params.get("lambda") {
                                Some(v) => v,
                                None => {
                                    respond_result!(req, false, "missing lambda");
                                    return;
                                }
                            };
                            let lambda = match lambda.parse::<u64>() {
                                Ok(v) => v,
                                Err(e) => {
                                    respond_result!(
                                        req,
                                        false,
                                        format!("error parsing lambda: {}", e)
                                    );
                                    return;
                                }
                            };
                            miner.stopTransmission(lambda);
                            respond_result!(req, true, "ok");
                        }
                        "/miner/resumetransmission" => {
                            let params = url.query_pairs();
                            let params: HashMap<_, _> = params.into_owned().collect();
                            let lambda = match params.get("lambda") {
                                Some(v) => v,
                                None => {
                                    respond_result!(req, false, "missing lambda");
                                    return;
                                }
                            };
                            let lambda = match lambda.parse::<u64>() {
                                Ok(v) => v,
                                Err(e) => {
                                    respond_result!(
                                        req,
                                        false,
                                        format!("error parsing lambda: {}", e)
                                    );
                                    return;
                                }
                            };
                            miner.resumeTransmission(lambda);
                            respond_result!(req, true, "ok");
                        }
                        "/miner/pausecpgeneration" => {
                            miner.stopCPGeneration();
                            respond_result!(req, true, "ok");
                        }
                        "/miner/resumecpgeneration" => {
                            miner.resumeCPGeneration();
                            respond_result!(req, true, "ok");
                        }
                        "/network/ping" => {
                            network.broadcast(Message::Ping(String::from("Test ping")));
                            respond_result!(req, true, "ok");
                        }
                        "/network/join" => {
                            let params = url.query_pairs();
                            let params: HashMap<_, _> = params.into_owned().collect();
                            let group = match params.get("group") {
                                Some(v) => v, 
                                None => {
                                    respond_result!(req, false, "missing group");
                                    return;
                                }
                            };
                            let group = match group.parse::<u64>() {
                                Ok(v) => v,
                                Err(e) => {
                                    respond_result!(
                                        req,
                                        false,
                                        format!("error parsing group: {}", e)
                                    );
                                    return;
                                }
                            };
                            let mut file = match File::open("./network_config.json") {
                                Ok(v) => v,
                                Err(e) => {
                                    respond_result!(
                                        req,
                                        false,
                                        format!("error reading network group configuration: {}", e)
                                    );
                                    return;
                                }
                            };
                            let mut data = String::new();
                            match file.read_to_string(&mut data) {
                                Ok(_) => {}, 
                                Err(e) => {
                                    respond_result!(
                                        req,
                                        false,
                                        format!("error reading network group configuration: {}", e)
                                    );
                                    return;
                                }
                            };
                            let net_config: serde_json::Value = match serde_json::from_str(&data) {
                                Ok(v) => v,
                                Err(e) => {
                                    respond_result!(
                                        req,
                                        false,
                                        format!("error parsing network group configuration json: {}", e)
                                    );
                                    return;
                                }
                            };
                            let group_info = match net_config.get(group.to_string()) {
                                Some(v) => v,
                                None => {
                                    respond_result!(
                                        req,
                                        false,
                                        format!("error accessing nonexisted network group configuration")
                                    );
                                    return;
                                }
                            };
                            for group_addr in group_info.as_array().unwrap().iter() {
                                let ip = group_addr.as_str().unwrap().clone();
                                loop {
                                    let addr = match ip.parse::<net::SocketAddr>() {
                                        Ok(x) => x,
                                        Err(e) => {
                                            error!("Error parsing peer address {}: {}", &ip, e);
                                            break;
                                        }
                                    };
                                    match network.connect(addr) {
                                        Ok(_) => {
                                            info!("Connected to outgoing peer {}", &addr);
                                            break;
                                        }
                                        Err(e) => {
                                            error!(
                                                "Error connecting to peer {}, retrying in one second: {}",
                                                addr, e
                                            );
                                            thread::sleep(time::Duration::from_millis(1000));
                                            continue;
                                        }
                                    }
                                }
                            }
                            respond_result!(req, true, "ok");
                        }
                        _ => {
                            let content_type =
                                "Content-Type: application/json".parse::<Header>().unwrap();
                            let payload = ApiResponse {
                                success: false,
                                message: "endpoint not found".to_string(),
                            };
                            let resp = Response::from_string(
                                serde_json::to_string_pretty(&payload).unwrap(),
                            )
                            .with_header(content_type)
                            .with_status_code(404);
                            req.respond(resp).unwrap();
                        }
                    }
                });
            }
        });
        info!("API server listening at {}", &addr);
    }
}
